/* =============================================================================
   EProfile — tarjeta de contacto (vCard 3.0)
   Genera un archivo .vcf real: al abrirlo, el teléfono o el gestor de correo
   ofrece guardar la persona en la agenda.
   ========================================================================== */

function escaparVCard(valor) {
  return String(valor || '')
    .replace(/\\/g, '\\\\')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,')
    .replace(/\r?\n/g, '\\n');
}

function partirNombre(completo) {
  var palabras = String(completo || '').trim().split(/\s+/).filter(Boolean);
  if (palabras.length <= 1) return { nombre: palabras[0] || '', apellido: '' };
  return { nombre: palabras[0], apellido: palabras.slice(1).join(' ') };
}

function construirVCard(perfil, slug) {
  var partes = partirNombre(perfil.nombre);
  var direccion = urlPerfil(slug);
  var lineas = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    'N:' + escaparVCard(partes.apellido) + ';' + escaparVCard(partes.nombre) + ';;;',
    'FN:' + escaparVCard(perfil.nombre),
  ];

  if (perfil.profesion) lineas.push('TITLE:' + escaparVCard(perfil.profesion));
  if (perfil.contacto && perfil.contacto.email) {
    lineas.push('EMAIL;TYPE=INTERNET,PREF:' + escaparVCard(perfil.contacto.email));
  }
  if (perfil.contacto && perfil.contacto.telefono) {
    lineas.push('TEL;TYPE=CELL:' + escaparVCard(perfil.contacto.telefono));
  }
  lineas.push('URL:' + escaparVCard(direccion));
  if (perfil.contacto && perfil.contacto.sitio) {
    lineas.push('URL;TYPE=WORK:' + escaparVCard(urlAbsoluta(perfil.contacto.sitio)));
  }
  if (perfil.ubicacion) {
    lineas.push('ADR;TYPE=WORK:;;' + escaparVCard(perfil.ubicacion) + ';;;;');
  }
  (perfil.enlaces || []).forEach(function (enlace) {
    if (enlace.url) lineas.push('URL;TYPE=' + escaparVCard(enlace.etiqueta || 'otro') + ':' + escaparVCard(urlAbsoluta(enlace.url)));
  });
  if (perfil.fotoUrl) lineas.push('PHOTO;VALUE=URI:' + escaparVCard(perfil.fotoUrl));
  if (perfil.resena) lineas.push('NOTE:' + escaparVCard(perfil.resena));

  lineas.push('REV:' + new Date().toISOString());
  lineas.push('END:VCARD');

  /* Las vCards usan finales de línea CRLF. */
  return lineas.join('\r\n') + '\r\n';
}

function descargarVCard(perfil, slug) {
  var contenido = construirVCard(perfil, slug);
  var nombreArchivo = (slug || 'contacto') + '.vcf';
  descargar(nombreArchivo, new Blob([contenido], { type: 'text/vcard;charset=utf-8' }));
}
