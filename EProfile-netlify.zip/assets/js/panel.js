/* =============================================================================
   EProfile — panel de edición del estudiante
   Un administrador puede abrir este mismo panel para cualquier estudiante; el
   permiso lo decide el servidor en cada petición.
   ========================================================================== */

var estado = {
  slug: '',
  borrador: null,
  publicado: null,
  cambiosSinPublicar: false,
  cambiosSinGuardar: false,
  actualizadoEn: null,
  publicadoEn: null,
  seccion: 'general',
  sesion: null,
};

/* --- Campos de formulario --------------------------------------------------- */

function campo(def, valor, alCambiar) {
  var id = 'campo-' + Math.random().toString(36).slice(2, 9);
  var control;

  if (def.tipo === 'area') {
    control = crear('textarea', { id: id, rows: def.filas || 4, maxlength: def.max || 900 });
    control.value = valor || '';
  } else if (def.tipo === 'casilla') {
    control = crear('input', { type: 'checkbox', id: id });
    control.checked = Boolean(valor);
  } else if (def.tipo === 'select') {
    control = crear('select', { id: id }, def.opciones.map(function (o) {
      return crear('option', { value: o.valor, texto: o.texto });
    }));
    control.value = valor || def.opciones[0].valor;
  } else {
    control = crear('input', { type: def.tipo || 'text', id: id, maxlength: def.max || 200 });
    control.value = valor || '';
    if (def.marcador) control.placeholder = def.marcador;
  }

  control.addEventListener('input', function () {
    alCambiar(def.tipo === 'casilla' ? control.checked : control.value);
  });
  control.addEventListener('change', function () {
    alCambiar(def.tipo === 'casilla' ? control.checked : control.value);
  });

  if (def.tipo === 'casilla') {
    return crear('div', { clase: 'campo' + (def.completo ? ' campo--completo' : '') }, [
      crear('label', { clase: 'casilla', for: id, style: 'font-weight:400' }, [
        control, document.createTextNode(' ' + def.etiqueta),
      ]),
      def.ayuda ? crear('div', { clase: 'ayuda', texto: def.ayuda }) : null,
    ]);
  }

  return crear('div', { clase: 'campo' + (def.completo ? ' campo--completo' : '') }, [
    crear('label', { for: id, texto: def.etiqueta }),
    control,
    def.ayuda ? crear('div', { clase: 'ayuda', texto: def.ayuda }) : null,
  ]);
}

function marcarCambios() {
  estado.cambiosSinGuardar = true;
  var indicador = $('#estado-guardado');
  if (indicador) indicador.textContent = 'Tienes cambios sin guardar.';
}

/* --- Editor de listas (formación, experiencia, proyectos, etc.) ------------- */

function editorLista(clave, definicion) {
  var contenedor = crear('div');

  function pintar() {
    contenedor.innerHTML = '';
    var lista = estado.borrador[clave];

    if (!lista.length) {
      contenedor.appendChild(crear('p', { clase: 'vacio', texto: definicion.vacio }));
    }

    lista.forEach(function (elemento, indice) {
      var fila = crear('div', { clase: 'fila-editable' });
      fila.appendChild(crear('div', { clase: 'fila-editable__barra' }, [
        crear('span', { clase: 'fila-editable__numero', texto: definicion.singular + ' ' + (indice + 1) }),
        crear('button', {
          clase: 'boton boton--sutil boton--pequeno', texto: 'Eliminar',
          onclick: async function () {
            var titulo = elemento[definicion.campos[0].clave] || definicion.singular.toLowerCase();
            var seguro = await confirmar(
              'Eliminar ' + definicion.singular.toLowerCase(),
              '¿Quieres eliminar «' + titulo + '»? El cambio se aplica al guardar el borrador.',
              'Eliminar'
            );
            if (!seguro) return;
            estado.borrador[clave].splice(indice, 1);
            marcarCambios();
            pintar();
          },
        }),
      ]));

      var rejilla = crear('div', { clase: 'rejilla-campos' });
      definicion.campos.forEach(function (def) {
        rejilla.appendChild(campo(def, elemento[def.clave], function (valor) {
          elemento[def.clave] = valor;
          marcarCambios();
        }));
      });
      fila.appendChild(rejilla);
      contenedor.appendChild(fila);
    });

    contenedor.appendChild(crear('button', {
      clase: 'boton boton--sutil', texto: definicion.textoAgregar,
      onclick: function () {
        var nuevo = { id: 'n' + Date.now().toString(36) };
        definicion.campos.forEach(function (d) { nuevo[d.clave] = d.tipo === 'casilla' ? false : ''; });
        estado.borrador[clave].push(nuevo);
        marcarCambios();
        pintar();
      },
    }));
  }

  pintar();
  return contenedor;
}

/* --- Secciones -------------------------------------------------------------- */

function seccionGeneral() {
  var b = estado.borrador;
  var contenedor = crear('div');

  /* --- fotografía --- */
  var vistaFoto = b.fotoUrl
    ? crear('img', { clase: 'perfil-foto', src: b.fotoUrl, alt: 'Fotografía actual' })
    : crear('div', { clase: 'perfil-foto perfil-foto--vacia', texto: iniciales(b.nombre) });

  var entradaArchivo = crear('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', style: 'display:none' });
  var avisoFoto = crear('div', { hidden: true, style: 'margin-top:10px' });
  var botonSubir = crear('button', {
    clase: 'boton', texto: b.fotoUrl ? 'Cambiar fotografía' : 'Subir fotografía',
    onclick: function () { entradaArchivo.click(); },
  });

  entradaArchivo.addEventListener('change', async function () {
    var archivo = entradaArchivo.files && entradaArchivo.files[0];
    if (!archivo) return;
    mostrarAviso(avisoFoto, '');

    var permitidos = ['image/jpeg', 'image/png', 'image/webp'];
    if (permitidos.indexOf(archivo.type) < 0) {
      mostrarAviso(avisoFoto, 'Solo se aceptan imágenes JPG, PNG o WEBP.', 'error');
      entradaArchivo.value = '';
      return;
    }
    if (archivo.size > 2 * 1024 * 1024) {
      mostrarAviso(avisoFoto, 'La imagen supera 2 MB. Usa una más ligera.', 'error');
      entradaArchivo.value = '';
      return;
    }

    botonSubir.disabled = true;
    botonSubir.textContent = 'Subiendo…';
    try {
      var base64 = await new Promise(function (resolver, rechazar) {
        var lector = new FileReader();
        lector.onload = function () { resolver(lector.result); };
        lector.onerror = rechazar;
        lector.readAsDataURL(archivo);
      });

      var respuesta = await api('/foto?slug=' + encodeURIComponent(estado.slug), {
        method: 'POST',
        cuerpo: { tipo: archivo.type, datos: base64 },
      });

      b.fotoUrl = respuesta.fotoUrl;
      estado.cambiosSinPublicar = true;
      mostrarAviso(avisoFoto, 'Fotografía actualizada. Publica el perfil para que se vea en público.', 'exito');
      dibujarSeccion();
      actualizarCabecera();
    } catch (e) {
      mostrarAviso(avisoFoto, e.message, 'error');
    }
    botonSubir.disabled = false;
    botonSubir.textContent = 'Cambiar fotografía';
    entradaArchivo.value = '';
  });

  var botonesFoto = [botonSubir];
  if (b.fotoUrl) {
    botonesFoto.push(crear('button', {
      clase: 'boton boton--sutil', texto: 'Quitar fotografía',
      onclick: async function () {
        var seguro = await confirmar('Quitar fotografía', '¿Quieres quitar tu fotografía del perfil?', 'Quitar');
        if (!seguro) return;
        try {
          await api('/foto?slug=' + encodeURIComponent(estado.slug), { method: 'POST', cuerpo: { quitar: true } });
          b.fotoUrl = '';
          estado.cambiosSinPublicar = true;
          dibujarSeccion();
          actualizarCabecera();
        } catch (e) {
          mostrarAviso(avisoFoto, e.message, 'error');
        }
      },
    }));
  }

  contenedor.appendChild(crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Fotografía' })]),
    crear('div', { clase: 'foto-editor' }, [
      vistaFoto,
      crear('div', {}, [
        crear('div', { clase: 'grupo-botones' }, botonesFoto),
        crear('div', { clase: 'ayuda', style: 'margin-top:10px', texto: 'JPG, PNG o WEBP. Máximo 2 MB. La imagen se guarda en Supabase Storage.' }),
        avisoFoto,
      ]),
      entradaArchivo,
    ]),
  ]));

  /* --- datos generales --- */
  var rejilla = crear('div', { clase: 'rejilla-campos' });
  [
    { clave: 'nombre', etiqueta: 'Nombre completo', max: 90, ayuda: 'Obligatorio para publicar.' },
    { clave: 'profesion', etiqueta: 'Carrera o profesión', max: 120, ayuda: 'Obligatorio para publicar.' },
    { clave: 'ubicacion', etiqueta: 'Ciudad', max: 90, completo: false },
  ].forEach(function (def) {
    rejilla.appendChild(campo(def, b[def.clave], function (valor) { b[def.clave] = valor; marcarCambios(); actualizarCabecera(); }));
  });
  rejilla.appendChild(campo({
    clave: 'resena', etiqueta: 'Reseña', tipo: 'area', filas: 5, max: 900, completo: true,
    ayuda: 'Una descripción breve de quién eres y qué haces.',
  }, b.resena, function (valor) { b.resena = valor; marcarCambios(); }));

  contenedor.appendChild(crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Datos generales' })]),
    rejilla,
  ]));

  return contenedor;
}

function seccionContacto() {
  var b = estado.borrador;
  var rejilla = crear('div', { clase: 'rejilla-campos' });

  [
    { clave: 'email', etiqueta: 'Correo', tipo: 'email', max: 120 },
    { clave: 'telefono', etiqueta: 'Teléfono', tipo: 'tel', max: 40, ayuda: 'Con código de país si quieres que funcione la llamada.' },
    { clave: 'sitio', etiqueta: 'Sitio web', max: 200, completo: true, marcador: 'ejemplo.com' },
  ].forEach(function (def) {
    rejilla.appendChild(campo(def, b.contacto[def.clave], function (valor) { b.contacto[def.clave] = valor; marcarCambios(); }));
  });

  return crear('div', {}, [
    crear('div', { clase: 'tarjeta' }, [
      crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Información de contacto' })]),
      rejilla,
    ]),
    crear('div', { clase: 'tarjeta' }, [
      crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Enlaces profesionales' })]),
      editorLista('enlaces', {
        singular: 'Enlace', textoAgregar: 'Agregar enlace',
        vacio: 'Todavía no has agregado enlaces (LinkedIn, GitHub, portafolio…).',
        campos: [
          { clave: 'etiqueta', etiqueta: 'Nombre del enlace', max: 40, marcador: 'LinkedIn' },
          { clave: 'url', etiqueta: 'Dirección', max: 300, marcador: 'linkedin.com/in/usuario' },
        ],
      }),
    ]),
  ]);
}

function seccionFormacion() {
  return crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Formación' })]),
    editorLista('formacion', {
      singular: 'Formación', textoAgregar: 'Agregar formación',
      vacio: 'Todavía no has agregado formación académica.',
      campos: [
        { clave: 'titulo', etiqueta: 'Título o programa', max: 120 },
        { clave: 'institucion', etiqueta: 'Institución', max: 120 },
        { clave: 'inicio', etiqueta: 'Inicio', max: 20, marcador: '2023' },
        { clave: 'fin', etiqueta: 'Fin', max: 20, marcador: 'Déjalo vacío si continúas' },
        { clave: 'descripcion', etiqueta: 'Descripción', tipo: 'area', max: 600, completo: true },
      ],
    }),
  ]);
}

function seccionExperiencia() {
  return crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Experiencia' })]),
    editorLista('experiencia', {
      singular: 'Experiencia', textoAgregar: 'Agregar experiencia',
      vacio: 'Todavía no has agregado experiencia. Si no tienes, deja la sección vacía: no aparecerá en tu perfil.',
      campos: [
        { clave: 'puesto', etiqueta: 'Puesto', max: 120 },
        { clave: 'empresa', etiqueta: 'Empresa u organización', max: 120 },
        { clave: 'inicio', etiqueta: 'Inicio', max: 20, marcador: 'Ene 2025' },
        { clave: 'fin', etiqueta: 'Fin', max: 20, marcador: 'Déjalo vacío si continúas' },
        { clave: 'descripcion', etiqueta: 'Descripción', tipo: 'area', max: 600, completo: true },
      ],
    }),
  ]);
}

function seccionHabilidades() {
  return crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Habilidades' })]),
    editorLista('habilidades', {
      singular: 'Habilidad', textoAgregar: 'Agregar habilidad',
      vacio: 'Todavía no has agregado habilidades.',
      campos: [
        { clave: 'nombre', etiqueta: 'Habilidad', max: 60, marcador: 'JavaScript' },
        {
          clave: 'nivel', etiqueta: 'Nivel', tipo: 'select',
          opciones: [
            { valor: '', texto: 'Sin especificar' },
            { valor: 'Básico', texto: 'Básico' },
            { valor: 'Intermedio', texto: 'Intermedio' },
            { valor: 'Avanzado', texto: 'Avanzado' },
          ],
        },
      ],
    }),
  ]);
}

function seccionProyectos() {
  return crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Proyectos' })]),
    editorLista('proyectos', {
      singular: 'Proyecto', textoAgregar: 'Agregar proyecto',
      vacio: 'Todavía no has agregado proyectos.',
      campos: [
        { clave: 'nombre', etiqueta: 'Nombre del proyecto', max: 120 },
        { clave: 'rol', etiqueta: 'Tu rol', max: 120, marcador: 'Desarrollo del frontend' },
        { clave: 'descripcion', etiqueta: 'Descripción', tipo: 'area', max: 800, completo: true },
        { clave: 'tecnologias', etiqueta: 'Tecnologías', max: 200, completo: true, marcador: 'JavaScript, HTML, CSS' },
        { clave: 'enlace', etiqueta: 'Enlace al proyecto', max: 300 },
        { clave: 'repositorio', etiqueta: 'Repositorio', max: 300 },
        {
          clave: 'academico', etiqueta: 'Es un proyecto académico', tipo: 'casilla', completo: true,
          ayuda: 'Se marcará como tal en tu perfil público y en el CV.',
        },
      ],
    }),
  ]);
}

function seccionReconocimientos() {
  return crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Reconocimientos' })]),
    editorLista('reconocimientos', {
      singular: 'Reconocimiento', textoAgregar: 'Agregar reconocimiento',
      vacio: 'Todavía no has agregado reconocimientos.',
      campos: [
        { clave: 'titulo', etiqueta: 'Reconocimiento', max: 120 },
        { clave: 'otorgadoPor', etiqueta: 'Otorgado por', max: 120 },
        { clave: 'fecha', etiqueta: 'Fecha', max: 20, marcador: '2025' },
        { clave: 'descripcion', etiqueta: 'Descripción', tipo: 'area', max: 600, completo: true },
      ],
    }),
  ]);
}

function seccionCv() {
  var b = estado.borrador;
  var opciones = crear('div', { style: 'display:grid;gap:10px' });

  PLANTILLAS_CV.forEach(function (plantilla) {
    var radio = crear('input', {
      type: 'radio', name: 'plantilla', value: plantilla.id,
      id: 'plantilla-' + plantilla.id, style: 'width:15px;height:15px;accent-color:var(--verde)',
    });
    radio.checked = b.plantillaCv === plantilla.id;
    radio.addEventListener('change', function () {
      if (radio.checked) { b.plantillaCv = plantilla.id; marcarCambios(); }
    });

    opciones.appendChild(crear('label', {
      for: 'plantilla-' + plantilla.id,
      style: 'display:flex;gap:12px;align-items:flex-start;border:1px solid var(--linea);border-radius:3px;padding:14px;cursor:pointer;background:var(--superficie)',
    }, [
      radio,
      crear('div', {}, [
        crear('div', { style: 'font-weight:600', texto: plantilla.nombre }),
        crear('div', { style: 'font-size:13px;color:var(--tinta-media)', texto: plantilla.descripcion }),
      ]),
    ]));
  });

  var avisoCv = crear('div', { hidden: true, style: 'margin-top:14px' });
  var botonDescargar = crear('button', { clase: 'boton boton--primario', texto: 'Descargar CV (borrador)' });
  botonDescargar.addEventListener('click', async function () {
    botonDescargar.disabled = true;
    botonDescargar.textContent = 'Generando…';
    try {
      await generarCvPdf(estado.borrador, estado.slug);
    } catch (e) {
      mostrarAviso(avisoCv, 'No pudimos generar el CV. Revisa tu conexión e intenta otra vez.', 'error');
    }
    botonDescargar.disabled = false;
    botonDescargar.textContent = 'Descargar CV (borrador)';
  });

  return crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Plantilla del CV' })]),
    crear('p', {
      style: 'color:var(--tinta-media);margin-bottom:16px',
      texto: 'El CV se arma con la misma información de tu perfil. Elige cómo quieres que se vea el PDF.',
    }),
    opciones,
    crear('div', { clase: 'grupo-botones', style: 'margin-top:18px' }, [botonDescargar]),
    avisoCv,
  ]);
}

function seccionPublicacion() {
  var avisoPub = crear('div', { hidden: true });

  var botonPublicar = crear('button', { clase: 'boton boton--publicar', texto: 'Publicar perfil' });
  botonPublicar.addEventListener('click', async function () {
    if (estado.cambiosSinGuardar) {
      var guardar = await confirmar(
        'Guardar antes de publicar',
        'Tienes cambios sin guardar. ¿Quieres guardarlos y publicar el perfil?',
        'Guardar y publicar'
      );
      if (!guardar) return;
      var seGuardo = await guardarBorrador();
      if (!seGuardo) return;
    }
    botonPublicar.disabled = true;
    botonPublicar.textContent = 'Publicando…';
    try {
      var respuesta = await api('/publicar?slug=' + encodeURIComponent(estado.slug), { method: 'POST' });
      estado.publicado = respuesta.publicado;
      estado.publicadoEn = respuesta.publicadoEn;
      estado.cambiosSinPublicar = false;
      mostrarAviso(avisoPub, 'Perfil publicado. Ya es visible para cualquier persona.', 'exito');
      actualizarCabecera();
    } catch (e) {
      mostrarAviso(avisoPub, e.message, 'error');
    }
    botonPublicar.disabled = false;
    botonPublicar.textContent = 'Publicar perfil';
  });

  var acciones = [
    botonPublicar,
    crear('a', {
      clase: 'boton', href: '/' + estado.slug + '?vista=borrador', target: '_blank',
      texto: 'Vista previa',
    }),
  ];

  if (estado.publicado) {
    acciones.push(crear('a', { clase: 'boton boton--sutil', href: '/' + estado.slug, target: '_blank', texto: 'Ver perfil público' }));
    acciones.push(crear('button', {
      clase: 'boton boton--sutil', texto: 'Retirar de la vista pública',
      onclick: async function () {
        var seguro = await confirmar(
          'Retirar el perfil',
          'Tu perfil dejará de aparecer en público hasta que lo vuelvas a publicar. Tu información no se borra.',
          'Retirar'
        );
        if (!seguro) return;
        try {
          await api('/despublicar?slug=' + encodeURIComponent(estado.slug), { method: 'POST' });
          estado.publicado = null;
          estado.publicadoEn = null;
          estado.cambiosSinPublicar = true;
          mostrarAviso(avisoPub, 'El perfil ya no aparece en público.', 'exito');
          dibujarSeccion();
          actualizarCabecera();
        } catch (e) {
          mostrarAviso(avisoPub, e.message, 'error');
        }
      },
    }));
  }

  var faltantes = [];
  if (!estado.borrador.nombre) faltantes.push('nombre completo');
  if (!estado.borrador.profesion) faltantes.push('carrera o profesión');

  var direccion = urlPerfil(estado.slug);

  return crear('div', {}, [
    crear('div', { clase: 'tarjeta' }, [
      crear('div', { clase: 'tarjeta__titulo' }, [
        crear('h2', { texto: 'Publicación' }),
        crear('span', {
          clase: 'estado ' + (estado.publicado ? 'estado--publicado' : 'estado--borrador'),
          texto: estado.publicado ? 'Publicado' : 'Sin publicar',
        }),
      ]),

      faltantes.length ? crear('div', { clase: 'aviso aviso--atencion' }, [
        crear('strong', { texto: 'Falta información para publicar' }),
        document.createTextNode('Completa tu ' + faltantes.join(' y tu ') + ' en la sección Datos generales.'),
      ]) : null,

      (!faltantes.length && estado.cambiosSinPublicar && estado.publicado) ? crear('div', { clase: 'aviso' }, [
        crear('strong', { texto: 'Tienes cambios sin publicar' }),
        document.createTextNode('Tu perfil público sigue mostrando la versión anterior hasta que publiques.'),
      ]) : null,

      avisoPub,
      crear('p', { style: 'color:var(--tinta-media)' }, [
        document.createTextNode('Última edición: ' + fechaHoraLegible(estado.actualizadoEn) + '. '),
        document.createTextNode('Última publicación: ' + fechaHoraLegible(estado.publicadoEn) + '.'),
      ]),
      crear('div', { clase: 'grupo-botones', style: 'margin-top:16px' }, acciones),
    ]),

    crear('div', { clase: 'tarjeta' }, [
      crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Compartir' })]),
      crear('p', { style: 'color:var(--tinta-media);margin-bottom:6px', texto: 'Dirección permanente de tu perfil:' }),
      crear('p', { style: 'font-family:monospace;font-size:14px;word-break:break-all;margin-bottom:16px', texto: direccion }),
      crear('div', { clase: 'grupo-botones' }, [
        crear('button', {
          clase: 'boton', texto: 'Ver código QR',
          onclick: function () { mostrarDialogoQR(estado.slug, estado.borrador.nombre); },
        }),
        crear('a', { clase: 'boton boton--sutil', href: '/' + estado.slug + '/tarjeta', target: '_blank', texto: 'Tarjeta digital' }),
        crear('button', {
          clase: 'boton boton--sutil', texto: 'Guardar contacto',
          onclick: function () { descargarVCard(estado.borrador, estado.slug); },
        }),
      ]),
    ]),
  ]);
}

function seccionCuenta() {
  var avisoClave = crear('div', { hidden: true });
  var actual = crear('input', { type: 'password', autocomplete: 'current-password' });
  var nueva = crear('input', { type: 'password', autocomplete: 'new-password' });
  var repetir = crear('input', { type: 'password', autocomplete: 'new-password' });

  var boton = crear('button', { clase: 'boton boton--primario', texto: 'Cambiar contraseña' });
  boton.addEventListener('click', async function () {
    mostrarAviso(avisoClave, '');
    if (!actual.value || !nueva.value) {
      mostrarAviso(avisoClave, 'Completa tu contraseña actual y la nueva.', 'error');
      return;
    }
    if (nueva.value.length < 8) {
      mostrarAviso(avisoClave, 'La nueva contraseña debe tener al menos 8 caracteres.', 'error');
      return;
    }
    if (nueva.value !== repetir.value) {
      mostrarAviso(avisoClave, 'La confirmación no coincide con la nueva contraseña.', 'error');
      return;
    }
    boton.disabled = true;
    try {
      await api('/password', { method: 'POST', cuerpo: { actual: actual.value, nueva: nueva.value } });
      actual.value = nueva.value = repetir.value = '';
      mostrarAviso(avisoClave, 'Contraseña actualizada.', 'exito');
    } catch (e) {
      mostrarAviso(avisoClave, e.message, 'error');
    }
    boton.disabled = false;
  });

  return crear('div', { clase: 'tarjeta' }, [
    crear('div', { clase: 'tarjeta__titulo' }, [crear('h2', { texto: 'Mi cuenta' })]),
    crear('p', { style: 'color:var(--tinta-media);margin-bottom:16px', texto: 'Sesión iniciada como ' + estado.sesion.usuario.email + '.' }),
    avisoClave,
    crear('div', { clase: 'campo' }, [crear('label', { texto: 'Contraseña actual' }), actual]),
    crear('div', { clase: 'campo' }, [crear('label', { texto: 'Nueva contraseña' }), nueva,
      crear('div', { clase: 'ayuda', texto: 'Mínimo 8 caracteres.' })]),
    crear('div', { clase: 'campo' }, [crear('label', { texto: 'Repetir la nueva contraseña' }), repetir]),
    boton,
  ]);
}

var SECCIONES = [
  { id: 'general', nombre: 'Datos generales', dibujar: seccionGeneral, editable: true },
  { id: 'contacto', nombre: 'Contacto y enlaces', dibujar: seccionContacto, editable: true },
  { id: 'formacion', nombre: 'Formación', dibujar: seccionFormacion, editable: true },
  { id: 'experiencia', nombre: 'Experiencia', dibujar: seccionExperiencia, editable: true },
  { id: 'habilidades', nombre: 'Habilidades', dibujar: seccionHabilidades, editable: true },
  { id: 'proyectos', nombre: 'Proyectos', dibujar: seccionProyectos, editable: true },
  { id: 'reconocimientos', nombre: 'Reconocimientos', dibujar: seccionReconocimientos, editable: true },
  { id: 'cv', nombre: 'CV', dibujar: seccionCv, editable: true },
  { id: 'publicacion', nombre: 'Publicación', dibujar: seccionPublicacion, editable: false },
  { id: 'cuenta', nombre: 'Mi cuenta', dibujar: seccionCuenta, editable: false },
];

/* --- Guardado --------------------------------------------------------------- */

async function guardarBorrador() {
  var indicador = $('#estado-guardado');
  var boton = $('#boton-guardar');
  if (boton) { boton.disabled = true; boton.textContent = 'Guardando…'; }
  if (indicador) indicador.textContent = 'Guardando…';

  try {
    var respuesta = await api('/perfil?slug=' + encodeURIComponent(estado.slug), {
      method: 'PUT',
      cuerpo: { perfil: estado.borrador },
    });
    estado.borrador = respuesta.borrador;
    estado.actualizadoEn = respuesta.actualizadoEn;
    estado.cambiosSinPublicar = respuesta.cambiosSinPublicar;
    estado.cambiosSinGuardar = false;
    if (indicador) indicador.textContent = 'Borrador guardado a las ' + new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }) + '.';
    mostrarAviso('#aviso-general', '');
    actualizarCabecera();
    dibujarSeccion();
    return true;
  } catch (e) {
    if (indicador) indicador.textContent = 'No se guardó.';
    mostrarAviso('#aviso-general', e.message, 'error');
    return false;
  } finally {
    if (boton) { boton.disabled = false; boton.textContent = 'Guardar borrador'; }
  }
}

/* --- Estructura de la página ------------------------------------------------ */

function actualizarCabecera() {
  var nombre = $('#cabecera-nombre');
  if (nombre) nombre.textContent = estado.borrador.nombre || 'Perfil sin nombre';

  var chip = $('#cabecera-estado');
  if (chip) {
    var publicado = Boolean(estado.publicado);
    var pendiente = publicado && estado.cambiosSinPublicar;
    chip.className = 'estado ' + (pendiente ? 'estado--borrador' : (publicado ? 'estado--publicado' : 'estado--borrador'));
    chip.textContent = pendiente ? 'Cambios sin publicar' : (publicado ? 'Publicado' : 'Sin publicar');
  }
}

function dibujarSeccion() {
  var definicion = SECCIONES.find(function (s) { return s.id === estado.seccion; }) || SECCIONES[0];
  var zona = $('#zona-seccion');
  if (!zona) return;
  zona.innerHTML = '';
  zona.appendChild(definicion.dibujar());

  if (definicion.editable) {
    zona.appendChild(crear('div', { clase: 'barra-guardado' }, [
      crear('button', { clase: 'boton boton--primario', id: 'boton-guardar', texto: 'Guardar borrador', onclick: guardarBorrador }),
      crear('a', { clase: 'boton boton--sutil', href: '/' + estado.slug + '?vista=borrador', target: '_blank', texto: 'Vista previa' }),
      crear('span', {
        clase: 'estado-guardado', id: 'estado-guardado',
        texto: estado.cambiosSinGuardar ? 'Tienes cambios sin guardar.' : 'Todo guardado.',
      }),
    ]));
  }

  $$('#panel-menu button').forEach(function (boton) {
    boton.setAttribute('aria-current', boton.dataset.seccion === estado.seccion ? 'true' : 'false');
  });
}

function dibujarPanel() {
  var contenido = $('#contenido');
  contenido.innerHTML = '';

  var esAdmin = estado.sesion.usuario.rol === 'admin';

  contenido.appendChild(crear('div', { clase: 'encabezado-pagina' }, [
    crear('div', { style: 'display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:6px' }, [
      crear('h1', { id: 'cabecera-nombre', texto: estado.borrador.nombre || 'Perfil sin nombre' }),
      crear('span', { clase: 'estado', id: 'cabecera-estado', texto: '' }),
    ]),
    crear('p', {}, [
      document.createTextNode('Editando el perfil publicado en '),
      crear('a', { href: '/' + estado.slug, texto: '/' + estado.slug }),
      document.createTextNode(esAdmin ? ' — estás entrando como administración.' : '.'),
    ]),
    esAdmin ? crear('p', { style: 'margin-top:8px' }, [
      crear('a', { href: '/admin', texto: '← Volver al listado de estudiantes' }),
    ]) : null,
  ]));

  var menu = crear('nav', { clase: 'panel-menu', id: 'panel-menu' });
  SECCIONES.forEach(function (s) {
    var boton = crear('button', { type: 'button', texto: s.nombre });
    boton.dataset.seccion = s.id;
    boton.addEventListener('click', function () {
      estado.seccion = s.id;
      dibujarSeccion();
    });
    menu.appendChild(boton);
  });

  contenido.appendChild(crear('div', { clase: 'panel-disposicion' }, [
    menu,
    crear('div', { id: 'zona-seccion' }),
  ]));

  actualizarCabecera();
  dibujarSeccion();
}

/* --- Arranque --------------------------------------------------------------- */

async function iniciarPanel() {
  var sesion = await montarBarra();
  var slug = slugDeRuta();
  var contenido = $('#contenido');

  if (!slug) { location.href = '/'; return; }

  if (!sesion.usuario) { irAEntrar('/' + slug + '/admin'); return; }
  estado.sesion = sesion;
  estado.slug = slug;

  try {
    var datos = await api('/perfil?slug=' + encodeURIComponent(slug));
    estado.borrador = datos.borrador;
    estado.publicado = datos.publicado;
    estado.actualizadoEn = datos.actualizadoEn;
    estado.publicadoEn = datos.publicadoEn;
    estado.cambiosSinPublicar = datos.cambiosSinPublicar;

    var advertencia = avisoPersistenciaTemporal(datos);
    if (advertencia) {
      var caja = $('#aviso-general');
      caja.hidden = false;
      caja.appendChild(advertencia);
    }

    dibujarPanel();
  } catch (e) {
    contenido.innerHTML = '';
    if (e.estado === 401) { irAEntrar('/' + slug + '/admin'); return; }
    contenido.appendChild(crear('div', { clase: 'no-encontrado' }, [
      crear('h1', { texto: e.estado === 403 ? 'Sin permisos' : 'No disponible' }),
      crear('p', { texto: e.message }),
      crear('a', {
        clase: 'boton boton--primario',
        href: sesion.slug ? '/' + sesion.slug + '/admin' : '/',
        texto: sesion.slug ? 'Ir a mi perfil' : 'Volver al inicio',
      }),
    ]));
  }
}

window.addEventListener('beforeunload', function (evento) {
  if (estado.cambiosSinGuardar) {
    evento.preventDefault();
    evento.returnValue = '';
  }
});

iniciarPanel();
