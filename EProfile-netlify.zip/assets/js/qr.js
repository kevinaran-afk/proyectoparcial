/* =============================================================================
   EProfile — código QR
   El QR apunta siempre a la dirección pública del perfil (por ejemplo
   https://sitio.netlify.app/fernanda). Esa dirección no cambia cuando el
   estudiante actualiza su información, así que un QR impreso sigue sirviendo.
   ========================================================================== */

var URL_QRIOUS = 'https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js';

async function dibujarQR(lienzo, valor, tamano) {
  await cargarScript(URL_QRIOUS);
  /* eslint-disable no-undef */
  new QRious({
    element: lienzo,
    value: valor,
    size: tamano || 320,
    padding: 0,
    level: 'M',
    background: '#ffffff',
    foreground: '#1a1917',
  });
  return lienzo;
}

function descargarQR(lienzo, slug) {
  lienzo.toBlob(function (blob) {
    descargar('qr-' + slug + '.png', blob);
  }, 'image/png');
}

function imprimirQR(lienzo, nombre, direccion) {
  var imagen = lienzo.toDataURL('image/png');
  var ventana = window.open('', '_blank', 'width=560,height=680');
  if (!ventana) {
    alert('Tu navegador bloqueó la ventana de impresión. Permite las ventanas emergentes de este sitio.');
    return;
  }
  ventana.document.write(
    '<!doctype html><html lang="es"><head><meta charset="utf-8">' +
    '<title>Código QR — ' + escaparHtml(nombre) + '</title><style>' +
    'body{font-family:Georgia,serif;text-align:center;padding:48px 24px;color:#1a1917}' +
    'img{width:280px;height:280px;border:1px solid #d9d5cb;padding:14px}' +
    'h1{font-size:20px;margin:24px 0 4px}' +
    'p{font-family:-apple-system,Segoe UI,Arial,sans-serif;font-size:13px;color:#4c4a44;margin:0}' +
    '</style></head><body>' +
    '<img src="' + imagen + '" alt="Código QR">' +
    '<h1>' + escaparHtml(nombre) + '</h1>' +
    '<p>' + escaparHtml(direccion) + '</p>' +
    '</body></html>'
  );
  ventana.document.close();
  ventana.focus();
  setTimeout(function () { ventana.print(); }, 350);
}

function escaparHtml(valor) {
  return String(valor || '').replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

/* Abre el diálogo con el QR del perfil, listo para ver, descargar o imprimir. */
async function mostrarDialogoQR(slug, nombre) {
  var direccion = urlPerfil(slug);
  var lienzo = crear('canvas', { width: 320, height: 320 });
  var caja = crear('div', { clase: 'qr-caja' }, [
    lienzo,
    crear('p', { texto: direccion }),
  ]);

  var cerrar = abrirDialogo('Código QR del perfil', caja, [
    crear('button', { clase: 'boton boton--sutil', texto: 'Cerrar', onclick: function () { cerrar(); } }),
    crear('button', {
      clase: 'boton boton--sutil', texto: 'Imprimir',
      onclick: function () { imprimirQR(lienzo, nombre, direccion); },
    }),
    crear('button', {
      clase: 'boton boton--primario', texto: 'Descargar',
      onclick: function () { descargarQR(lienzo, slug); },
    }),
  ]);

  try {
    await dibujarQR(lienzo, direccion, 320);
  } catch (e) {
    caja.insertBefore(crear('div', { clase: 'aviso aviso--error', texto: 'No pudimos generar el código QR. Revisa tu conexión e intenta otra vez.' }), lienzo);
  }
}
