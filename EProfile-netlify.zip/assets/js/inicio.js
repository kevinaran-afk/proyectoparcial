/* =============================================================================
   EProfile — página principal: directorio de perfiles publicados
   ========================================================================== */

function fichaPerfil(perfil) {
  var foto = perfil.fotoUrl
    ? crear('img', { clase: 'ficha__foto', src: perfil.fotoUrl, alt: 'Fotografía de ' + perfil.nombre, loading: 'lazy' })
    : crear('div', { clase: 'ficha__foto ficha__foto--vacia', texto: iniciales(perfil.nombre) });

  return crear('a', { clase: 'ficha', href: '/' + perfil.slug }, [
    foto,
    crear('div', {}, [
      crear('div', { clase: 'ficha__nombre', texto: perfil.nombre }),
      perfil.profesion ? crear('div', { clase: 'ficha__profesion', texto: perfil.profesion }) : null,
      crear('div', { clase: 'ficha__ruta', texto: '/' + perfil.slug }),
    ]),
  ]);
}

async function iniciarPortada() {
  montarBarra('/');

  var directorio = $('#directorio');
  try {
    var datos = await api('/perfiles');
    directorio.innerHTML = '';

    if (!datos.perfiles.length) {
      directorio.appendChild(crear('p', {
        clase: 'vacio',
        texto: 'Todavía no hay perfiles publicados.',
      }));
    } else {
      datos.perfiles.forEach(function (perfil) { directorio.appendChild(fichaPerfil(perfil)); });
    }
  } catch (e) {
    directorio.innerHTML = '';
    directorio.appendChild(crear('div', { clase: 'aviso aviso--error', texto: e.message }));
  }

  $('#forma-buscar').addEventListener('submit', async function (evento) {
    evento.preventDefault();
    var valor = $('#campo-buscar').value.trim().toLowerCase().replace(/^\/+|\/+$/g, '');
    if (!valor) {
      mostrarAviso('#aviso-buscar', 'Escribe la dirección del perfil que quieres abrir.', 'error');
      return;
    }
    mostrarAviso('#aviso-buscar', '');
    try {
      await api('/perfil-publico?slug=' + encodeURIComponent(valor));
      location.href = '/' + valor;
    } catch (e) {
      mostrarAviso('#aviso-buscar', e.message, 'error');
    }
  });
}

iniciarPortada();
