/* =============================================================================
   EProfile — panel de administración
   El servidor vuelve a comprobar el rol en cada petición: si alguien abre esta
   página sin ser administrador, la API responde 403 y aquí no se muestra nada.
   ========================================================================== */

var estudiantes = [];

function campoDialogo(etiqueta, control, ayuda) {
  return crear('div', { clase: 'campo' }, [
    crear('label', { texto: etiqueta }),
    control,
    ayuda ? crear('div', { clase: 'ayuda', texto: ayuda }) : null,
  ]);
}

async function recargar() {
  var datos = await api('/admin/estudiantes');
  estudiantes = datos.estudiantes;
  return datos;
}

/* --- Diálogos --------------------------------------------------------------- */

function dialogoNuevoEstudiante() {
  var nombre = crear('input', { type: 'text', maxlength: 90 });
  var email = crear('input', { type: 'email', maxlength: 120 });
  var slug = crear('input', { type: 'text', maxlength: 40, placeholder: 'se genera desde el nombre' });
  var password = crear('input', { type: 'password', autocomplete: 'new-password' });
  var aviso = crear('div', { hidden: true });

  nombre.addEventListener('input', function () {
    if (!slug.dataset.tocado) {
      slug.value = nombre.value.toLowerCase().normalize('NFD')
        .replace(/[̀-ͯ]/g, '')
        .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    }
  });
  slug.addEventListener('input', function () { slug.dataset.tocado = '1'; });

  var boton = crear('button', { clase: 'boton boton--primario', texto: 'Crear estudiante' });

  var cerrar = abrirDialogo('Nuevo estudiante', crear('div', {}, [
    aviso,
    campoDialogo('Nombre completo', nombre),
    campoDialogo('Correo', email, 'Con este correo iniciará sesión.'),
    campoDialogo('Dirección del perfil', slug, 'Es la parte final de la dirección: solo letras, números y guiones.'),
    campoDialogo('Contraseña inicial', password, 'Mínimo 8 caracteres.'),
  ]), [
    crear('button', { clase: 'boton boton--sutil', texto: 'Cancelar', onclick: function () { cerrar(); } }),
    boton,
  ]);

  boton.addEventListener('click', async function () {
    mostrarAviso(aviso, '');
    boton.disabled = true;
    try {
      await api('/admin/estudiantes', {
        method: 'POST',
        cuerpo: {
          nombre: nombre.value.trim(), email: email.value.trim(),
          slug: slug.value.trim(), password: password.value,
        },
      });
      cerrar();
      await dibujar();
      mostrarAviso('#aviso-general', 'Estudiante creado.', 'exito');
    } catch (e) {
      mostrarAviso(aviso, e.message, 'error');
      boton.disabled = false;
    }
  });
}

function dialogoEditar(estudiante) {
  var nombre = crear('input', { type: 'text', maxlength: 90, value: estudiante.nombre });
  var email = crear('input', { type: 'email', maxlength: 120, value: estudiante.email });
  var slug = crear('input', { type: 'text', maxlength: 40, value: estudiante.slug });
  var aviso = crear('div', { hidden: true });
  var boton = crear('button', { clase: 'boton boton--primario', texto: 'Guardar cambios' });

  var cerrar = abrirDialogo('Editar estudiante', crear('div', {}, [
    aviso,
    campoDialogo('Nombre completo', nombre),
    campoDialogo('Correo', email),
    campoDialogo('Dirección del perfil', slug, 'Si la cambias, los códigos QR impresos con la dirección anterior dejarán de funcionar.'),
  ]), [
    crear('button', { clase: 'boton boton--sutil', texto: 'Cancelar', onclick: function () { cerrar(); } }),
    boton,
  ]);

  boton.addEventListener('click', async function () {
    mostrarAviso(aviso, '');
    boton.disabled = true;
    try {
      await api('/admin/estudiantes?id=' + encodeURIComponent(estudiante.id), {
        method: 'PUT',
        cuerpo: { nombre: nombre.value.trim(), email: email.value.trim(), slug: slug.value.trim() },
      });
      cerrar();
      await dibujar();
      mostrarAviso('#aviso-general', 'Datos actualizados.', 'exito');
    } catch (e) {
      mostrarAviso(aviso, e.message, 'error');
      boton.disabled = false;
    }
  });
}

function dialogoPassword(estudiante) {
  var password = crear('input', { type: 'password', autocomplete: 'new-password' });
  var aviso = crear('div', { hidden: true });
  var boton = crear('button', { clase: 'boton boton--primario', texto: 'Restablecer' });

  var cerrar = abrirDialogo('Restablecer contraseña', crear('div', {}, [
    aviso,
    crear('p', { style: 'color:var(--tinta-media);margin-bottom:16px' }, [
      document.createTextNode('Se asignará una contraseña nueva a '),
      crear('b', { texto: estudiante.email }),
      document.createTextNode('. Comunícasela para que pueda entrar.'),
    ]),
    campoDialogo('Nueva contraseña', password, 'Mínimo 8 caracteres.'),
  ]), [
    crear('button', { clase: 'boton boton--sutil', texto: 'Cancelar', onclick: function () { cerrar(); } }),
    boton,
  ]);

  boton.addEventListener('click', async function () {
    mostrarAviso(aviso, '');
    boton.disabled = true;
    try {
      await api('/admin/password?id=' + encodeURIComponent(estudiante.id), {
        method: 'POST', cuerpo: { password: password.value },
      });
      cerrar();
      mostrarAviso('#aviso-general', 'Contraseña restablecida para ' + estudiante.email + '.', 'exito');
    } catch (e) {
      mostrarAviso(aviso, e.message, 'error');
      boton.disabled = false;
    }
  });
}

/* --- Tabla ------------------------------------------------------------------ */

function filaEstudiante(estudiante) {
  var chipPerfil = crear('span', {
    clase: 'estado ' + (estudiante.publicado
      ? (estudiante.cambiosSinPublicar ? 'estado--borrador' : 'estado--publicado')
      : 'estado--borrador'),
    texto: estudiante.publicado
      ? (estudiante.cambiosSinPublicar ? 'Cambios sin publicar' : 'Publicado')
      : 'Borrador',
  });

  var chipCuenta = crear('span', {
    clase: 'estado ' + (estudiante.activo ? '' : 'estado--inactivo'),
    texto: estudiante.activo ? 'Activa' : 'Desactivada',
  });

  return crear('tr', {}, [
    crear('td', {}, [
      crear('div', { style: 'font-weight:600', texto: estudiante.nombre || '(sin nombre)' }),
      estudiante.profesion ? crear('div', { style: 'font-size:12px;color:var(--tenue)', texto: estudiante.profesion }) : null,
    ]),
    crear('td', { texto: estudiante.email }),
    crear('td', {}, [crear('a', { href: '/' + estudiante.slug, target: '_blank', texto: '/' + estudiante.slug })]),
    crear('td', {}, [chipPerfil]),
    crear('td', {}, [chipCuenta]),
    crear('td', { style: 'font-size:13px;color:var(--tinta-media);white-space:nowrap', texto: fechaLegible(estudiante.actualizadoEn) }),
    crear('td', {}, [
      crear('div', { clase: 'acciones' }, [
        crear('a', {
          clase: 'boton boton--sutil boton--pequeno',
          href: '/' + estudiante.slug + '/admin', texto: 'Administrar perfil',
        }),
        crear('button', {
          clase: 'boton boton--sutil boton--pequeno', texto: 'Editar',
          onclick: function () { dialogoEditar(estudiante); },
        }),
        crear('button', {
          clase: 'boton boton--sutil boton--pequeno',
          texto: estudiante.activo ? 'Desactivar' : 'Activar',
          onclick: async function () {
            if (estudiante.activo) {
              var seguro = await confirmar(
                'Desactivar estudiante',
                'Su perfil dejará de verse en público y no podrá iniciar sesión. La información se conserva.',
                'Desactivar'
              );
              if (!seguro) return;
            }
            try {
              await api('/admin/estudiantes?id=' + encodeURIComponent(estudiante.id), {
                method: 'PUT', cuerpo: { activo: !estudiante.activo },
              });
              await dibujar();
            } catch (e) {
              mostrarAviso('#aviso-general', e.message, 'error');
            }
          },
        }),
        crear('button', {
          clase: 'boton boton--sutil boton--pequeno', texto: 'Contraseña',
          onclick: function () { dialogoPassword(estudiante); },
        }),
        crear('button', {
          clase: 'boton boton--sutil boton--pequeno', texto: 'Eliminar',
          onclick: async function () {
            var seguro = await confirmar(
              'Eliminar estudiante',
              'Se borrarán su perfil y su cuenta de forma permanente. Esta acción no se puede deshacer.',
              'Eliminar'
            );
            if (!seguro) return;
            try {
              await api('/admin/estudiantes?id=' + encodeURIComponent(estudiante.id), { method: 'DELETE' });
              await dibujar();
              mostrarAviso('#aviso-general', 'Estudiante eliminado.', 'exito');
            } catch (e) {
              mostrarAviso('#aviso-general', e.message, 'error');
            }
          },
        }),
      ]),
    ]),
  ]);
}

async function dibujar() {
  var contenido = $('#contenido');
  var datos = await recargar();

  contenido.innerHTML = '';
  contenido.appendChild(crear('div', { clase: 'encabezado-pagina' }, [
    crear('h1', { texto: 'Administración' }),
    crear('p', { texto: 'Estudiantes registrados en la plataforma, estado de sus perfiles y de sus cuentas.' }),
  ]));

  var advertencia = avisoPersistenciaTemporal(datos);
  if (advertencia) contenido.appendChild(advertencia);

  contenido.appendChild(crear('div', {
    clase: 'grupo-botones', style: 'margin-bottom:20px',
  }, [
    crear('button', { clase: 'boton boton--primario', texto: 'Nuevo estudiante', onclick: dialogoNuevoEstudiante }),
    crear('a', { clase: 'boton boton--sutil', href: '/api/admin/exportar', target: '_blank', texto: 'Ver el archivo JSON' }),
  ]));

  if (!estudiantes.length) {
    contenido.appendChild(crear('p', { clase: 'vacio', texto: 'Todavía no hay estudiantes registrados.' }));
    return;
  }

  var cabecera = crear('tr', {}, ['Estudiante', 'Correo', 'Dirección', 'Perfil', 'Cuenta', 'Actualizado', 'Acciones']
    .map(function (t) { return crear('th', { texto: t }); }));

  contenido.appendChild(crear('div', { clase: 'tabla-envoltura' }, [
    crear('table', {}, [
      crear('thead', {}, [cabecera]),
      crear('tbody', {}, estudiantes.map(filaEstudiante)),
    ]),
  ]));
}

/* --- Arranque --------------------------------------------------------------- */

async function iniciarAdmin() {
  var sesion = await montarBarra('/admin');
  var contenido = $('#contenido');

  if (!sesion.usuario) { irAEntrar('/admin'); return; }

  try {
    await dibujar();
  } catch (e) {
    contenido.innerHTML = '';
    if (e.estado === 401) { irAEntrar('/admin'); return; }
    contenido.appendChild(crear('div', { clase: 'no-encontrado' }, [
      crear('h1', { texto: e.estado === 403 ? 'Sin permisos' : 'No disponible' }),
      crear('p', { texto: e.message }),
      crear('a', {
        clase: 'boton boton--primario',
        href: sesion.slug ? '/' + sesion.slug + '/admin' : '/',
        texto: sesion.slug ? 'Ir a mi perfil' : 'Volver al inicio',
      }),
    ]));
  }
}

iniciarAdmin();
