/* =============================================================================
   EProfile — tarjeta de presentación digital
   Pensada para verse en pantalla y para imprimirse: al imprimir se ocultan la
   barra y los botones y queda solo la tarjeta.
   ========================================================================== */

async function iniciarTarjeta() {
  montarBarra();
  var slug = slugDeRuta();
  var contenido = $('#contenido');

  if (!slug) { location.href = '/'; return; }

  var perfil;
  try {
    var datos = await api('/perfil-publico?slug=' + encodeURIComponent(slug));
    perfil = datos.perfil;
  } catch (e) {
    contenido.innerHTML = '';
    contenido.appendChild(crear('div', { clase: 'no-encontrado' }, [
      crear('h1', { texto: 'Tarjeta no disponible' }),
      crear('p', { texto: e.message }),
      crear('a', { clase: 'boton boton--primario', href: '/', texto: 'Volver al inicio' }),
    ]));
    return;
  }

  document.title = 'Tarjeta de ' + perfil.nombre + ' — EProfile';
  var direccion = urlPerfil(slug);
  var lienzo = crear('canvas', { width: 96, height: 96, style: 'width:96px;height:96px' });

  var foto = perfil.fotoUrl
    ? crear('img', { clase: 'tarjeta-digital__foto', src: perfil.fotoUrl, alt: 'Fotografía de ' + perfil.nombre })
    : crear('div', { clase: 'tarjeta-digital__foto perfil-foto--vacia', style: 'font-size:26px', texto: iniciales(perfil.nombre) });

  var datosContacto = crear('div', { clase: 'tarjeta-digital__datos' }, [
    perfil.contacto && perfil.contacto.email ? crear('div', { texto: perfil.contacto.email }) : null,
    perfil.contacto && perfil.contacto.telefono ? crear('div', { texto: perfil.contacto.telefono }) : null,
    perfil.ubicacion ? crear('div', { texto: perfil.ubicacion }) : null,
    crear('div', { style: 'margin-top:6px;color:var(--tenue)', texto: direccion.replace(/^https?:\/\//, '') }),
  ]);

  var tarjeta = crear('div', { clase: 'tarjeta-digital' }, [
    crear('div', { clase: 'tarjeta-digital__superior' }, [
      foto,
      crear('div', {}, [
        crear('div', { clase: 'tarjeta-digital__nombre', texto: perfil.nombre }),
        perfil.profesion ? crear('div', { clase: 'tarjeta-digital__profesion', texto: perfil.profesion }) : null,
      ]),
    ]),
    crear('div', { clase: 'tarjeta-digital__inferior' }, [datosContacto, lienzo]),
  ]);

  contenido.innerHTML = '';
  contenido.appendChild(crear('div', { clase: 'encabezado-pagina no-imprimir' }, [
    crear('h1', { texto: 'Tarjeta digital' }),
    crear('p', { texto: 'Comparte esta tarjeta en pantalla o imprímela. El código QR lleva directamente al perfil.' }),
  ]));
  contenido.appendChild(tarjeta);
  contenido.appendChild(crear('div', {
    clase: 'grupo-botones no-imprimir',
    style: 'margin-top:26px;justify-content:center',
  }, [
    crear('button', { clase: 'boton boton--primario', texto: 'Imprimir', onclick: function () { window.print(); } }),
    crear('button', {
      clase: 'boton', texto: 'Guardar contacto',
      onclick: function () { descargarVCard(perfil, slug); },
    }),
    crear('button', {
      clase: 'boton boton--sutil', texto: 'Descargar QR',
      onclick: function () { descargarQR(lienzo, slug); },
    }),
    crear('a', { clase: 'boton boton--sutil', href: '/' + slug, texto: 'Ver perfil completo' }),
  ]));

  try {
    await dibujarQR(lienzo, direccion, 96);
  } catch (e) {
    lienzo.replaceWith(crear('div', { style: 'font-size:12px;color:var(--tenue)', texto: 'No pudimos generar el QR.' }));
  }
}

iniciarTarjeta();
