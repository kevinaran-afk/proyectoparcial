/* =============================================================================
   EProfile — generación del CV en PDF
   El PDF se arma con los MISMOS datos que muestra la EProfile: no existe una
   segunda fuente de información para el currículum.
   Hay tres plantillas y cada una produce un documento distinto de verdad
   (tipografía, retícula y jerarquía diferentes), no solo un color cambiado.
   ========================================================================== */

var URL_JSPDF = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';

var PLANTILLAS_CV = [
  { id: 'minimalista', nombre: 'Minimalista', descripcion: 'Una columna, mucho aire y tipografía de palo seco.' },
  { id: 'profesional', nombre: 'Profesional', descripcion: 'Columna lateral en verde con contacto y habilidades.' },
  { id: 'clasica', nombre: 'Clásica', descripcion: 'Tipografía con serifas, encabezado centrado y filetes.' },
];

/* --- Imagen ---------------------------------------------------------------- */

async function imagenParaPdf(url, circular) {
  if (!url) return null;
  try {
    var respuesta = await fetch(url, { mode: 'cors', cache: 'force-cache' });
    if (!respuesta.ok) return null;
    var blob = await respuesta.blob();
    var objeto = URL.createObjectURL(blob);

    var imagen = await new Promise(function (resolver, rechazar) {
      var img = new Image();
      img.onload = function () { resolver(img); };
      img.onerror = rechazar;
      img.src = objeto;
    });

    var lado = Math.min(imagen.width, imagen.height);
    var lienzo = document.createElement('canvas');
    lienzo.width = 400;
    lienzo.height = 400;
    var ctx = lienzo.getContext('2d');

    if (circular) {
      ctx.beginPath();
      ctx.arc(200, 200, 200, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
    } else {
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, 400, 400);
    }
    /* Recorte centrado para que la foto no se deforme. */
    ctx.drawImage(imagen, (imagen.width - lado) / 2, (imagen.height - lado) / 2, lado, lado, 0, 0, 400, 400);
    URL.revokeObjectURL(objeto);
    return lienzo.toDataURL('image/png');
  } catch (e) {
    return null; /* El CV se genera igual, sin fotografía. */
  }
}

/* --- Utilidades de composición --------------------------------------------- */

function nuevoContexto(doc, config) {
  return Object.assign({
    doc: doc,
    x: 22, ancho: 166, y: 22, arriba: 22, abajo: 278,
    fuente: 'helvetica', color: [26, 25, 23],
    alCambiarPagina: null,
  }, config || {});
}

function espacio(ctx, alto) {
  if (ctx.y + alto > ctx.abajo) {
    ctx.doc.addPage();
    ctx.y = ctx.arriba;
    if (ctx.alCambiarPagina) ctx.alCambiarPagina(ctx);
    return true;
  }
  return false;
}

function escribir(ctx, contenido, opciones) {
  var o = opciones || {};
  var doc = ctx.doc;
  var tamano = o.tamano || 10;
  var anchoTexto = o.ancho || ctx.ancho;
  var x = o.x !== undefined ? o.x : ctx.x;

  doc.setFont(o.fuente || ctx.fuente, o.estilo || 'normal');
  doc.setFontSize(tamano);
  var color = o.color || ctx.color;
  doc.setTextColor(color[0], color[1], color[2]);

  var lineas = doc.splitTextToSize(String(contenido || ''), anchoTexto);
  var alturaLinea = tamano * 0.3528 * (o.interlineado || 1.35);

  for (var i = 0; i < lineas.length; i++) {
    espacio(ctx, alturaLinea);
    ctx.y += alturaLinea;
    doc.text(lineas[i], x, ctx.y, o.alinear ? { align: o.alinear } : undefined);
  }
  if (o.despues) ctx.y += o.despues;
  return ctx.y;
}

function linea(ctx, opciones) {
  var o = opciones || {};
  var doc = ctx.doc;
  var color = o.color || [217, 213, 203];
  espacio(ctx, 4);
  ctx.y += o.antes || 0;
  doc.setDrawColor(color[0], color[1], color[2]);
  doc.setLineWidth(o.grosor || 0.2);
  doc.line(o.x !== undefined ? o.x : ctx.x, ctx.y, (o.x !== undefined ? o.x : ctx.x) + (o.ancho || ctx.ancho), ctx.y);
  ctx.y += o.despues || 0;
}

function textoEspaciado(valor, separacion) {
  return String(valor || '').toUpperCase().split('').join(separacion || ' ');
}

function contactoEnLinea(perfil, slug) {
  var partes = [];
  if (perfil.contacto && perfil.contacto.email) partes.push(perfil.contacto.email);
  if (perfil.contacto && perfil.contacto.telefono) partes.push(perfil.contacto.telefono);
  if (perfil.ubicacion) partes.push(perfil.ubicacion);
  partes.push(urlPerfil(slug).replace(/^https?:\/\//, ''));
  return partes;
}

function hay(lista) { return Array.isArray(lista) && lista.length > 0; }

/* --- Plantilla 1: minimalista ---------------------------------------------- */

async function plantillaMinimalista(doc, perfil, slug) {
  var ctx = nuevoContexto(doc, { x: 22, ancho: 166, y: 24, arriba: 24, abajo: 276 });
  var gris = [124, 120, 110];
  var foto = await imagenParaPdf(perfil.fotoUrl, true);

  if (foto) {
    doc.addImage(foto, 'PNG', 160, 22, 28, 28);
    ctx.ancho = 130;
  }

  escribir(ctx, perfil.nombre, { tamano: 24, estilo: 'normal', interlineado: 1.15 });
  if (perfil.profesion) escribir(ctx, perfil.profesion, { tamano: 11, color: [60, 90, 69], despues: 2 });
  escribir(ctx, contactoEnLinea(perfil, slug).join('   ·   '), { tamano: 8.5, color: gris, ancho: 166, despues: 5 });

  ctx.ancho = 166;
  linea(ctx, { grosor: 0.5, color: [26, 25, 23], despues: 8 });

  function seccion(titulo) {
    espacio(ctx, 18);
    escribir(ctx, textoEspaciado(titulo, ' '), { tamano: 7.5, estilo: 'bold', color: gris, despues: 3 });
  }

  if (perfil.resena) {
    seccion('Perfil');
    escribir(ctx, perfil.resena, { tamano: 9.5, interlineado: 1.5, color: [76, 74, 68], despues: 7 });
  }

  if (hay(perfil.experiencia)) {
    seccion('Experiencia');
    perfil.experiencia.forEach(function (e) {
      espacio(ctx, 16);
      escribir(ctx, e.puesto || e.empresa, { tamano: 10.5, estilo: 'bold' });
      var sub = [e.empresa, periodo(e.inicio, e.fin)].filter(Boolean).join('   ·   ');
      if (sub) escribir(ctx, sub, { tamano: 8.5, color: gris });
      if (e.descripcion) escribir(ctx, e.descripcion, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.45 });
      ctx.y += 4;
    });
    ctx.y += 3;
  }

  if (hay(perfil.formacion)) {
    seccion('Formación');
    perfil.formacion.forEach(function (f) {
      espacio(ctx, 14);
      escribir(ctx, f.titulo || f.institucion, { tamano: 10.5, estilo: 'bold' });
      var sub = [f.institucion, periodo(f.inicio, f.fin)].filter(Boolean).join('   ·   ');
      if (sub) escribir(ctx, sub, { tamano: 8.5, color: gris });
      if (f.descripcion) escribir(ctx, f.descripcion, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.45 });
      ctx.y += 4;
    });
    ctx.y += 3;
  }

  if (hay(perfil.habilidades)) {
    seccion('Habilidades');
    escribir(ctx, perfil.habilidades.map(function (h) {
      return h.nivel ? h.nombre + ' (' + h.nivel + ')' : h.nombre;
    }).join('   ·   '), { tamano: 9.5, color: [76, 74, 68], interlineado: 1.5, despues: 7 });
  }

  if (hay(perfil.proyectos)) {
    seccion('Proyectos');
    perfil.proyectos.forEach(function (p) {
      espacio(ctx, 16);
      escribir(ctx, p.nombre + (p.academico ? '   [proyecto académico]' : ''), { tamano: 10.5, estilo: 'bold' });
      if (p.rol) escribir(ctx, p.rol, { tamano: 8.5, color: gris });
      if (p.descripcion) escribir(ctx, p.descripcion, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.45 });
      if (p.tecnologias) escribir(ctx, 'Tecnologías: ' + p.tecnologias, { tamano: 8.5, color: gris });
      var enlaces = [p.enlace, p.repositorio].filter(Boolean).join('   ·   ');
      if (enlaces) escribir(ctx, enlaces, { tamano: 8.5, color: gris });
      ctx.y += 4;
    });
    ctx.y += 3;
  }

  if (hay(perfil.reconocimientos)) {
    seccion('Reconocimientos');
    perfil.reconocimientos.forEach(function (r) {
      espacio(ctx, 12);
      escribir(ctx, r.titulo, { tamano: 10.5, estilo: 'bold' });
      var sub = [r.otorgadoPor, r.fecha].filter(Boolean).join('   ·   ');
      if (sub) escribir(ctx, sub, { tamano: 8.5, color: gris });
      if (r.descripcion) escribir(ctx, r.descripcion, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.45 });
      ctx.y += 4;
    });
  }

  if (hay(perfil.enlaces)) {
    seccion('Enlaces');
    perfil.enlaces.forEach(function (e) {
      escribir(ctx, (e.etiqueta ? e.etiqueta + ': ' : '') + e.url, { tamano: 9, color: [76, 74, 68] });
    });
  }
}

/* --- Plantilla 2: profesional (columna lateral) ---------------------------- */

async function plantillaProfesional(doc, perfil, slug) {
  var VERDE = [60, 90, 69];
  var ANCHO_LATERAL = 66;
  var foto = await imagenParaPdf(perfil.fotoUrl, true);

  function fondoLateral() {
    doc.setFillColor(VERDE[0], VERDE[1], VERDE[2]);
    doc.rect(0, 0, ANCHO_LATERAL, 297, 'F');
  }
  fondoLateral();

  /* --- columna lateral --- */
  var lat = nuevoContexto(doc, {
    x: 12, ancho: ANCHO_LATERAL - 24, y: 18, arriba: 18, abajo: 280,
    color: [255, 255, 255],
  });

  if (foto) {
    doc.addImage(foto, 'PNG', (ANCHO_LATERAL - 34) / 2, 18, 34, 34);
    lat.y = 58;
  }

  function seccionLateral(titulo) {
    lat.y += 6;
    escribir(lat, textoEspaciado(titulo, ' '), { tamano: 7, estilo: 'bold', color: [198, 214, 201] });
    linea(lat, { antes: 1.5, despues: 3, color: [110, 140, 118], grosor: 0.3, x: 12, ancho: ANCHO_LATERAL - 24 });
  }

  seccionLateral('Contacto');
  if (perfil.contacto && perfil.contacto.email) escribir(lat, perfil.contacto.email, { tamano: 8, interlineado: 1.4 });
  if (perfil.contacto && perfil.contacto.telefono) escribir(lat, perfil.contacto.telefono, { tamano: 8, interlineado: 1.4 });
  if (perfil.ubicacion) escribir(lat, perfil.ubicacion, { tamano: 8, interlineado: 1.4 });
  escribir(lat, urlPerfil(slug).replace(/^https?:\/\//, ''), { tamano: 7.5, interlineado: 1.4 });

  if (hay(perfil.habilidades)) {
    seccionLateral('Habilidades');
    perfil.habilidades.forEach(function (h) {
      escribir(lat, h.nombre, { tamano: 8.5, interlineado: 1.3 });
      if (h.nivel) escribir(lat, h.nivel, { tamano: 7, color: [198, 214, 201], interlineado: 1.3 });
      lat.y += 1.5;
    });
  }

  if (hay(perfil.enlaces)) {
    seccionLateral('Enlaces');
    perfil.enlaces.forEach(function (e) {
      escribir(lat, e.etiqueta || 'Enlace', { tamano: 8.5, interlineado: 1.3 });
      escribir(lat, String(e.url).replace(/^https?:\/\//, ''), { tamano: 6.8, color: [198, 214, 201], interlineado: 1.3 });
      lat.y += 1.5;
    });
  }

  /* Si la columna lateral llegó a desbordar a otra página, la columna
     principal debe empezar igualmente en la primera. */
  doc.setPage(1);

  /* --- columna principal --- */
  var ctx = nuevoContexto(doc, {
    x: ANCHO_LATERAL + 14, ancho: 210 - ANCHO_LATERAL - 14 - 16,
    y: 22, arriba: 22, abajo: 276,
    alCambiarPagina: fondoLateral,
  });
  var gris = [110, 106, 98];

  escribir(ctx, perfil.nombre, { tamano: 21, interlineado: 1.15 });
  if (perfil.profesion) escribir(ctx, perfil.profesion, { tamano: 10, color: VERDE, despues: 4 });

  function seccion(titulo) {
    espacio(ctx, 20);
    ctx.y += 3;
    escribir(ctx, textoEspaciado(titulo, ' '), { tamano: 7.5, estilo: 'bold', color: VERDE });
    linea(ctx, { antes: 1.5, despues: 3.5, grosor: 0.3 });
  }

  if (perfil.resena) {
    seccion('Perfil');
    escribir(ctx, perfil.resena, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.5, despues: 3 });
  }

  if (hay(perfil.experiencia)) {
    seccion('Experiencia');
    perfil.experiencia.forEach(function (e) {
      espacio(ctx, 16);
      escribir(ctx, e.puesto || e.empresa, { tamano: 10.5, estilo: 'bold' });
      var sub = [e.empresa, periodo(e.inicio, e.fin)].filter(Boolean).join('  ·  ');
      if (sub) escribir(ctx, sub, { tamano: 8.5, color: gris });
      if (e.descripcion) escribir(ctx, e.descripcion, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.45 });
      ctx.y += 4;
    });
  }

  if (hay(perfil.formacion)) {
    seccion('Formación');
    perfil.formacion.forEach(function (f) {
      espacio(ctx, 14);
      escribir(ctx, f.titulo || f.institucion, { tamano: 10.5, estilo: 'bold' });
      var sub = [f.institucion, periodo(f.inicio, f.fin)].filter(Boolean).join('  ·  ');
      if (sub) escribir(ctx, sub, { tamano: 8.5, color: gris });
      if (f.descripcion) escribir(ctx, f.descripcion, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.45 });
      ctx.y += 4;
    });
  }

  if (hay(perfil.proyectos)) {
    seccion('Proyectos');
    perfil.proyectos.forEach(function (p) {
      espacio(ctx, 16);
      escribir(ctx, p.nombre + (p.academico ? '  [académico]' : ''), { tamano: 10.5, estilo: 'bold' });
      if (p.rol) escribir(ctx, p.rol, { tamano: 8.5, color: gris });
      if (p.descripcion) escribir(ctx, p.descripcion, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.45 });
      if (p.tecnologias) escribir(ctx, 'Tecnologías: ' + p.tecnologias, { tamano: 8.5, color: gris });
      var enlaces = [p.enlace, p.repositorio].filter(Boolean).join('  ·  ');
      if (enlaces) escribir(ctx, enlaces, { tamano: 8, color: gris });
      ctx.y += 4;
    });
  }

  if (hay(perfil.reconocimientos)) {
    seccion('Reconocimientos');
    perfil.reconocimientos.forEach(function (r) {
      espacio(ctx, 12);
      escribir(ctx, r.titulo, { tamano: 10.5, estilo: 'bold' });
      var sub = [r.otorgadoPor, r.fecha].filter(Boolean).join('  ·  ');
      if (sub) escribir(ctx, sub, { tamano: 8.5, color: gris });
      if (r.descripcion) escribir(ctx, r.descripcion, { tamano: 9.5, color: [76, 74, 68], interlineado: 1.45 });
      ctx.y += 4;
    });
  }
}

/* --- Plantilla 3: clásica (serifas) ---------------------------------------- */

async function plantillaClasica(doc, perfil, slug) {
  var ctx = nuevoContexto(doc, {
    x: 25, ancho: 160, y: 24, arriba: 24, abajo: 274, fuente: 'times',
  });
  var gris = [100, 96, 90];
  var centro = 105;
  var foto = await imagenParaPdf(perfil.fotoUrl, true);

  if (foto) {
    doc.addImage(foto, 'PNG', centro - 13, ctx.y, 26, 26);
    ctx.y += 30;
  }

  escribir(ctx, textoEspaciado(perfil.nombre, ' '), {
    tamano: 17, estilo: 'bold', x: centro, alinear: 'center', interlineado: 1.25,
  });
  if (perfil.profesion) {
    escribir(ctx, perfil.profesion, { tamano: 11, estilo: 'italic', x: centro, alinear: 'center', color: [76, 74, 68] });
  }
  ctx.y += 1;
  escribir(ctx, contactoEnLinea(perfil, slug).join('  |  '), {
    tamano: 8.5, x: centro, alinear: 'center', color: gris, despues: 3,
  });

  linea(ctx, { grosor: 0.6, color: [26, 25, 23] });
  linea(ctx, { antes: 0.9, grosor: 0.2, color: [26, 25, 23], despues: 7 });

  function seccion(titulo) {
    espacio(ctx, 20);
    escribir(ctx, textoEspaciado(titulo, ' '), {
      tamano: 9, estilo: 'bold', x: centro, alinear: 'center', color: [26, 25, 23],
    });
    linea(ctx, { antes: 1.5, despues: 4, grosor: 0.2, color: [26, 25, 23] });
  }

  if (perfil.resena) {
    seccion('Perfil profesional');
    escribir(ctx, perfil.resena, { tamano: 10.5, interlineado: 1.45, color: [40, 39, 36], despues: 5 });
  }

  if (hay(perfil.formacion)) {
    seccion('Formación académica');
    perfil.formacion.forEach(function (f) {
      espacio(ctx, 14);
      escribir(ctx, f.titulo || f.institucion, { tamano: 11, estilo: 'bold' });
      var sub = [f.institucion, periodo(f.inicio, f.fin)].filter(Boolean).join(', ');
      if (sub) escribir(ctx, sub, { tamano: 10, estilo: 'italic', color: gris });
      if (f.descripcion) escribir(ctx, f.descripcion, { tamano: 10, interlineado: 1.4, color: [40, 39, 36] });
      ctx.y += 3.5;
    });
    ctx.y += 2;
  }

  if (hay(perfil.experiencia)) {
    seccion('Experiencia');
    perfil.experiencia.forEach(function (e) {
      espacio(ctx, 16);
      escribir(ctx, e.puesto || e.empresa, { tamano: 11, estilo: 'bold' });
      var sub = [e.empresa, periodo(e.inicio, e.fin)].filter(Boolean).join(', ');
      if (sub) escribir(ctx, sub, { tamano: 10, estilo: 'italic', color: gris });
      if (e.descripcion) escribir(ctx, e.descripcion, { tamano: 10, interlineado: 1.4, color: [40, 39, 36] });
      ctx.y += 3.5;
    });
    ctx.y += 2;
  }

  if (hay(perfil.proyectos)) {
    seccion('Proyectos');
    perfil.proyectos.forEach(function (p) {
      espacio(ctx, 16);
      escribir(ctx, p.nombre + (p.academico ? ' (proyecto académico)' : ''), { tamano: 11, estilo: 'bold' });
      if (p.rol) escribir(ctx, p.rol, { tamano: 10, estilo: 'italic', color: gris });
      if (p.descripcion) escribir(ctx, p.descripcion, { tamano: 10, interlineado: 1.4, color: [40, 39, 36] });
      if (p.tecnologias) escribir(ctx, 'Tecnologías: ' + p.tecnologias, { tamano: 9.5, color: gris });
      var enlaces = [p.enlace, p.repositorio].filter(Boolean).join('  |  ');
      if (enlaces) escribir(ctx, enlaces, { tamano: 9.5, color: gris });
      ctx.y += 3.5;
    });
    ctx.y += 2;
  }

  if (hay(perfil.habilidades)) {
    seccion('Habilidades');
    escribir(ctx, perfil.habilidades.map(function (h) {
      return h.nivel ? h.nombre + ' (' + h.nivel + ')' : h.nombre;
    }).join(' · '), { tamano: 10, interlineado: 1.45, color: [40, 39, 36], despues: 5 });
  }

  if (hay(perfil.reconocimientos)) {
    seccion('Reconocimientos');
    perfil.reconocimientos.forEach(function (r) {
      espacio(ctx, 12);
      escribir(ctx, r.titulo, { tamano: 11, estilo: 'bold' });
      var sub = [r.otorgadoPor, r.fecha].filter(Boolean).join(', ');
      if (sub) escribir(ctx, sub, { tamano: 10, estilo: 'italic', color: gris });
      if (r.descripcion) escribir(ctx, r.descripcion, { tamano: 10, interlineado: 1.4, color: [40, 39, 36] });
      ctx.y += 3.5;
    });
    ctx.y += 2;
  }

  if (hay(perfil.enlaces)) {
    seccion('Enlaces');
    perfil.enlaces.forEach(function (e) {
      escribir(ctx, (e.etiqueta ? e.etiqueta + ': ' : '') + e.url, {
        tamano: 10, x: centro, alinear: 'center', color: [40, 39, 36],
      });
    });
  }
}

/* --- Punto de entrada ------------------------------------------------------ */

async function generarCvPdf(perfil, slug) {
  await cargarScript(URL_JSPDF);
  /* eslint-disable no-undef */
  var doc = new window.jspdf.jsPDF({ unit: 'mm', format: 'a4', compress: true });

  var plantilla = perfil.plantillaCv || 'minimalista';
  if (plantilla === 'profesional') await plantillaProfesional(doc, perfil, slug);
  else if (plantilla === 'clasica') await plantillaClasica(doc, perfil, slug);
  else await plantillaMinimalista(doc, perfil, slug);

  doc.setProperties({
    title: 'CV — ' + perfil.nombre,
    subject: perfil.profesion || '',
    author: perfil.nombre || '',
    creator: 'EProfile',
  });

  var nombreArchivo = 'CV-' + String(perfil.nombre || slug)
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '') + '.pdf';
  doc.save(nombreArchivo);
}
