/* =============================================================================
   EProfile — utilidades compartidas por todas las páginas
   ========================================================================== */

/* --- Selección y creación de elementos ------------------------------------ */

function $(selector, raiz) { return (raiz || document).querySelector(selector); }
function $$(selector, raiz) { return Array.prototype.slice.call((raiz || document).querySelectorAll(selector)); }

function crear(etiqueta, propiedades, hijos) {
  var el = document.createElement(etiqueta);
  if (propiedades) {
    Object.keys(propiedades).forEach(function (clave) {
      var valor = propiedades[clave];
      if (valor === null || valor === undefined || valor === false) return;
      if (clave === 'clase') el.className = valor;
      else if (clave === 'texto') el.textContent = valor;
      else if (clave === 'html') el.innerHTML = valor;
      else if (clave.indexOf('on') === 0) el.addEventListener(clave.slice(2).toLowerCase(), valor);
      else el.setAttribute(clave, valor === true ? '' : valor);
    });
  }
  (hijos || []).forEach(function (hijo) {
    if (hijo === null || hijo === undefined || hijo === false) return;
    el.appendChild(typeof hijo === 'string' ? document.createTextNode(hijo) : hijo);
  });
  return el;
}

/* --- Cliente de la API ----------------------------------------------------
   Todas las respuestas de error llegan con un mensaje ya redactado para la
   persona que usa el sistema; aquí nunca se muestra un detalle técnico.
   -------------------------------------------------------------------------- */

var MENSAJE_GENERICO = 'No pudimos conectar con el servidor. Revisa tu conexión e intenta nuevamente.';

async function api(ruta, opciones) {
  var config = Object.assign({ credentials: 'same-origin', headers: {} }, opciones || {});
  if (config.cuerpo !== undefined) {
    config.headers['content-type'] = 'application/json';
    config.body = JSON.stringify(config.cuerpo);
    delete config.cuerpo;
  }

  var respuesta;
  try {
    respuesta = await fetch('/api' + ruta, config);
  } catch (e) {
    throw Object.assign(new Error(MENSAJE_GENERICO), { estado: 0 });
  }

  var datos = null;
  try { datos = await respuesta.json(); } catch (e) { datos = null; }

  if (!respuesta.ok || (datos && datos.ok === false)) {
    var mensaje = (datos && datos.mensaje) || 'Los datos no pudieron procesarse. Intenta nuevamente.';
    throw Object.assign(new Error(mensaje), { estado: respuesta.status, datos: datos });
  }
  if (!datos) throw Object.assign(new Error(MENSAJE_GENERICO), { estado: respuesta.status });
  return datos;
}

/* --- Sesión --------------------------------------------------------------- */

var _sesion = null;

async function obtenerSesion(forzar) {
  if (_sesion && !forzar) return _sesion;
  try {
    var datos = await api('/sesion');
    _sesion = { usuario: datos.usuario, slug: datos.slug, persistencia: datos.persistencia };
  } catch (e) {
    _sesion = { usuario: null, slug: null };
  }
  return _sesion;
}

async function cerrarSesion() {
  try { await api('/logout', { method: 'POST' }); } catch (e) { /* la cookie caduca sola */ }
  _sesion = null;
  location.href = '/';
}

function irAEntrar(destino) {
  location.href = '/entrar?destino=' + encodeURIComponent(destino || location.pathname);
}

/* --- Barra superior -------------------------------------------------------- */

async function montarBarra(activa) {
  var barra = $('#barra');
  if (!barra) return null;
  var sesion = await obtenerSesion();
  var nav = crear('nav', { clase: 'barra__nav' });

  nav.appendChild(crear('a', { href: '/', texto: 'Inicio' }));

  if (sesion.usuario) {
    if (sesion.usuario.rol === 'admin') {
      nav.appendChild(crear('a', { href: '/admin', texto: 'Administración' }));
    } else if (sesion.slug) {
      nav.appendChild(crear('a', { href: '/' + sesion.slug + '/admin', texto: 'Mi perfil' }));
      nav.appendChild(crear('a', { href: '/' + sesion.slug, texto: 'Ver perfil público' }));
    }
    nav.appendChild(crear('span', { clase: 'barra__usuario', texto: sesion.usuario.email }));
    nav.appendChild(crear('button', {
      clase: 'boton boton--sutil boton--pequeno', texto: 'Cerrar sesión', onclick: cerrarSesion,
    }));
  } else {
    nav.appendChild(crear('a', { href: '/entrar', texto: 'Iniciar sesión' }));
  }

  barra.innerHTML = '';
  barra.appendChild(crear('div', { clase: 'barra__interior' }, [
    crear('a', { clase: 'marca', href: '/', html: 'E<span>Profile</span>' }),
    nav,
  ]));

  if (activa) {
    $$('a', nav).forEach(function (a) {
      if (a.getAttribute('href') === activa) a.style.color = 'var(--tinta)';
    });
  }
  return sesion;
}

/* --- Avisos --------------------------------------------------------------- */

function mostrarAviso(contenedor, mensaje, tipo) {
  var caja = typeof contenedor === 'string' ? $(contenedor) : contenedor;
  if (!caja) return;
  if (!mensaje) { caja.innerHTML = ''; caja.hidden = true; return; }
  caja.hidden = false;
  caja.innerHTML = '';
  caja.appendChild(crear('div', { clase: 'aviso aviso--' + (tipo || 'error'), texto: mensaje }));
  caja.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function avisoPersistenciaTemporal(datos) {
  if (!datos || datos.persistencia !== 'temporal') return null;
  return crear('div', { clase: 'aviso aviso--atencion' }, [
    crear('strong', { texto: 'Almacenamiento sin configurar' }),
    document.createTextNode('Supabase Storage todavía no está configurado, así que los cambios se guardan de forma temporal y pueden perderse. Revisa la sección de configuración del README.'),
  ]);
}

/* --- Ruta y textos --------------------------------------------------------- */

function slugDeRuta() {
  var partes = location.pathname.split('/').filter(Boolean);
  return partes.length ? decodeURIComponent(partes[0]).toLowerCase() : '';
}

function urlPerfil(slug) {
  return location.origin + '/' + slug;
}

function fechaLegible(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' });
  } catch (e) { return '—'; }
}

function fechaHoraLegible(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('es-MX', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
    });
  } catch (e) { return '—'; }
}

function periodo(inicio, fin) {
  if (!inicio && !fin) return '';
  if (inicio && !fin) return inicio + ' — Actualidad';
  if (!inicio && fin) return fin;
  return inicio + ' — ' + fin;
}

function iniciales(nombre) {
  var palabras = String(nombre || '').trim().split(/\s+/).filter(Boolean);
  if (!palabras.length) return '·';
  return (palabras[0][0] + (palabras[1] ? palabras[1][0] : '')).toUpperCase();
}

function urlAbsoluta(valor) {
  var v = String(valor || '').trim();
  if (!v) return '';
  return /^https?:\/\//i.test(v) ? v : 'https://' + v;
}

/* --- Descargas y carga de librerías ---------------------------------------- */

function descargar(nombreArchivo, contenido, tipo) {
  var blob = contenido instanceof Blob ? contenido : new Blob([contenido], { type: tipo || 'text/plain;charset=utf-8' });
  var url = URL.createObjectURL(blob);
  var enlace = crear('a', { href: url, download: nombreArchivo });
  document.body.appendChild(enlace);
  enlace.click();
  document.body.removeChild(enlace);
  setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
}

var _scripts = {};
function cargarScript(url) {
  if (_scripts[url]) return _scripts[url];
  _scripts[url] = new Promise(function (resolver, rechazar) {
    var etiqueta = document.createElement('script');
    etiqueta.src = url;
    etiqueta.onload = resolver;
    etiqueta.onerror = function () { rechazar(new Error('No se pudo cargar un componente necesario.')); };
    document.head.appendChild(etiqueta);
  });
  return _scripts[url];
}

/* --- Diálogos -------------------------------------------------------------- */

function abrirDialogo(titulo, contenido, acciones) {
  var caja = crear('div', { clase: 'dialogo__caja', role: 'dialog', 'aria-modal': 'true' }, [
    crear('h2', { texto: titulo }),
    contenido,
    crear('div', { clase: 'dialogo__acciones' }, acciones || []),
  ]);
  var fondo = crear('div', { clase: 'dialogo' }, [caja]);
  fondo.addEventListener('click', function (e) { if (e.target === fondo) cerrar(); });
  function alPresionar(e) { if (e.key === 'Escape') cerrar(); }
  function cerrar() {
    document.removeEventListener('keydown', alPresionar);
    if (fondo.parentNode) fondo.parentNode.removeChild(fondo);
  }
  document.addEventListener('keydown', alPresionar);
  document.body.appendChild(fondo);
  return cerrar;
}

function confirmar(titulo, mensaje, textoBoton) {
  return new Promise(function (resolver) {
    var cerrar = abrirDialogo(titulo, crear('p', { texto: mensaje }), [
      crear('button', {
        clase: 'boton boton--sutil', texto: 'Cancelar',
        onclick: function () { cerrar(); resolver(false); },
      }),
      crear('button', {
        clase: 'boton boton--primario', texto: textoBoton || 'Confirmar',
        onclick: function () { cerrar(); resolver(true); },
      }),
    ]);
  });
}
