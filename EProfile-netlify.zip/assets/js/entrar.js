/* =============================================================================
   EProfile — inicio de sesión
   La validación real ocurre en el servidor; aquí solo se evita enviar el
   formulario vacío y se muestra el mensaje que devuelve la API.
   ========================================================================== */

function destinoSolicitado() {
  var parametros = new URLSearchParams(location.search);
  var destino = parametros.get('destino') || '';
  /* Solo se admiten rutas internas: nunca una dirección externa. */
  return /^\/[A-Za-z0-9\-/_?=&%.]*$/.test(destino) ? destino : '';
}

async function iniciarEntrar() {
  var sesion = await montarBarra('/entrar');

  /* Si ya hay sesión abierta, no tiene sentido volver a pedir credenciales. */
  if (sesion && sesion.usuario) {
    location.href = sesion.usuario.rol === 'admin'
      ? '/admin'
      : (sesion.slug ? '/' + sesion.slug + '/admin' : '/');
    return;
  }

  var forma = $('#forma-entrar');
  var boton = $('#boton-entrar');

  forma.addEventListener('submit', async function (evento) {
    evento.preventDefault();
    var email = $('#email').value.trim();
    var password = $('#password').value;

    if (!email || !password) {
      mostrarAviso('#aviso', 'Escribe tu correo y tu contraseña.', 'error');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
      mostrarAviso('#aviso', 'El correo no tiene un formato válido.', 'error');
      return;
    }

    mostrarAviso('#aviso', '');
    boton.disabled = true;
    boton.textContent = 'Entrando…';

    try {
      var datos = await api('/login', { method: 'POST', cuerpo: { email: email, password: password } });
      var destino = destinoSolicitado();
      if (destino) { location.href = destino; return; }
      location.href = datos.usuario.rol === 'admin'
        ? '/admin'
        : (datos.slug ? '/' + datos.slug + '/admin' : '/');
    } catch (e) {
      mostrarAviso('#aviso', e.message, 'error');
      boton.disabled = false;
      boton.textContent = 'Entrar';
    }
  });
}

iniciarEntrar();
