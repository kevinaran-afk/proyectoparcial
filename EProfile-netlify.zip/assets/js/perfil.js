/* =============================================================================
   EProfile — perfil público
   Muestra únicamente la información PUBLICADA. Con ?vista=borrador muestra el
   borrador, pero solo si quien mira tiene permiso sobre ese perfil: esa
   comprobación la hace el servidor, no esta página.
   ========================================================================== */

function seccion(titulo, contenido) {
  return crear('section', { clase: 'seccion' }, [
    crear('h2', { clase: 'etiqueta-seccion', texto: titulo }),
    contenido,
  ]);
}

function entradaCronologica(titulo, lugar, fechas, descripcion) {
  return crear('article', { clase: 'entrada' }, [
    crear('div', { clase: 'entrada__fila' }, [
      crear('div', {}, [
        crear('div', { clase: 'entrada__titulo', texto: titulo }),
        lugar ? crear('div', { clase: 'entrada__lugar', texto: lugar }) : null,
      ]),
      fechas ? crear('div', { clase: 'entrada__fechas', texto: fechas }) : null,
    ]),
    descripcion ? crear('p', { clase: 'entrada__descripcion', texto: descripcion }) : null,
  ]);
}

function bloqueProyecto(p) {
  var enlaces = crear('div', { clase: 'proyecto__enlaces' }, [
    p.enlace ? crear('a', { href: urlAbsoluta(p.enlace), target: '_blank', rel: 'noopener noreferrer', texto: 'Ver proyecto' }) : null,
    p.repositorio ? crear('a', { href: urlAbsoluta(p.repositorio), target: '_blank', rel: 'noopener noreferrer', texto: 'Repositorio' }) : null,
  ]);

  return crear('article', { clase: 'proyecto' }, [
    crear('div', { clase: 'proyecto__cabecera' }, [
      crear('h3', { texto: p.nombre }),
      p.academico ? crear('span', { clase: 'marca-academica', texto: 'Académico' }) : null,
    ]),
    p.descripcion ? crear('p', { style: 'font-size:14px;color:var(--tinta-media)', texto: p.descripcion }) : null,
    (p.rol || p.tecnologias) ? crear('div', { clase: 'proyecto__meta' }, [
      p.rol ? crear('div', {}, [crear('b', { texto: 'Rol: ' }), document.createTextNode(p.rol)]) : null,
      p.tecnologias ? crear('div', {}, [crear('b', { texto: 'Tecnologías: ' }), document.createTextNode(p.tecnologias)]) : null,
    ]) : null,
    (p.enlace || p.repositorio) ? enlaces : null,
  ]);
}

function bloqueCv(perfil, slug) {
  function grupo(titulo, hijos) {
    if (!hijos || !hijos.length) return null;
    return crear('div', { clase: 'cv__bloque' }, [crear('h4', { texto: titulo })].concat(hijos));
  }

  var lineaContacto = [
    perfil.contacto && perfil.contacto.email,
    perfil.contacto && perfil.contacto.telefono,
    perfil.ubicacion,
    urlPerfil(slug).replace(/^https?:\/\//, ''),
  ].filter(Boolean).join('  ·  ');

  return crear('div', { clase: 'cv' }, [
    crear('div', { clase: 'cv__cabecera' }, [
      crear('h3', { texto: perfil.nombre }),
      perfil.profesion ? crear('div', { clase: 'cv__linea', texto: perfil.profesion }) : null,
      crear('div', { clase: 'cv__linea', texto: lineaContacto }),
    ]),

    perfil.resena ? grupo('Perfil', [crear('p', { style: 'font-size:14px;color:var(--tinta-media)', texto: perfil.resena })]) : null,

    grupo('Formación', (perfil.formacion || []).map(function (f) {
      return entradaCronologica(f.titulo || f.institucion, f.institucion, periodo(f.inicio, f.fin), f.descripcion);
    })),

    grupo('Experiencia', (perfil.experiencia || []).map(function (e) {
      return entradaCronologica(e.puesto || e.empresa, e.empresa, periodo(e.inicio, e.fin), e.descripcion);
    })),

    grupo('Habilidades', (perfil.habilidades || []).length ? [
      crear('div', { clase: 'etiquetas' }, perfil.habilidades.map(function (h) {
        return crear('span', { clase: 'etiqueta' }, [
          crear('b', { texto: h.nombre }),
          h.nivel ? crear('i', { texto: '  ' + h.nivel }) : null,
        ]);
      })),
    ] : null),

    grupo('Proyectos', (perfil.proyectos || []).map(function (p) {
      return entradaCronologica(
        p.nombre + (p.academico ? '  ·  Proyecto académico' : ''),
        [p.rol, p.tecnologias].filter(Boolean).join('  ·  '),
        '', p.descripcion
      );
    })),

    grupo('Reconocimientos', (perfil.reconocimientos || []).map(function (r) {
      return entradaCronologica(r.titulo, r.otorgadoPor, r.fecha, r.descripcion);
    })),
  ]);
}

function barraAcciones(perfil, slug) {
  var botonCv = crear('button', { clase: 'boton boton--primario', texto: 'Descargar CV' });
  botonCv.addEventListener('click', async function () {
    botonCv.disabled = true;
    var original = botonCv.textContent;
    botonCv.textContent = 'Generando…';
    try {
      await generarCvPdf(perfil, slug);
    } catch (e) {
      mostrarAviso('#aviso-vista', 'No pudimos generar el CV. Revisa tu conexión e intenta otra vez.', 'error');
    }
    botonCv.disabled = false;
    botonCv.textContent = original;
  });

  return crear('div', { clase: 'acciones-perfil no-imprimir' }, [
    botonCv,
    crear('button', {
      clase: 'boton', texto: 'Guardar contacto',
      onclick: function () { descargarVCard(perfil, slug); },
    }),
    crear('button', {
      clase: 'boton', texto: 'Ver código QR',
      onclick: function () { mostrarDialogoQR(slug, perfil.nombre); },
    }),
    crear('a', { clase: 'boton boton--sutil', href: '/' + slug + '/tarjeta', texto: 'Tarjeta digital' }),
  ]);
}

function dibujarPerfil(perfil, slug, esBorrador) {
  var contenido = $('#contenido');
  contenido.innerHTML = '';
  document.title = perfil.nombre + ' — EProfile';

  var foto = perfil.fotoUrl
    ? crear('img', { clase: 'perfil-foto', src: perfil.fotoUrl, alt: 'Fotografía de ' + perfil.nombre })
    : crear('div', { clase: 'perfil-foto perfil-foto--vacia', texto: iniciales(perfil.nombre) });

  contenido.appendChild(crear('header', { clase: 'perfil-cabecera' }, [
    foto,
    crear('div', { clase: 'perfil-cabecera__texto' }, [
      crear('h1', { texto: perfil.nombre }),
      perfil.profesion ? crear('div', { clase: 'perfil-profesion', texto: perfil.profesion }) : null,
      perfil.ubicacion ? crear('div', { clase: 'perfil-ubicacion', texto: perfil.ubicacion }) : null,
      perfil.resena ? crear('p', { clase: 'perfil-resena', texto: perfil.resena }) : null,
    ]),
  ]));

  contenido.appendChild(barraAcciones(perfil, slug));

  /* Cada sección se agrega solo si tiene contenido. */

  if ((perfil.formacion || []).length) {
    contenido.appendChild(seccion('Formación', crear('div', {}, perfil.formacion.map(function (f) {
      return entradaCronologica(f.titulo || f.institucion, f.institucion, periodo(f.inicio, f.fin), f.descripcion);
    }))));
  }

  if ((perfil.experiencia || []).length) {
    contenido.appendChild(seccion('Experiencia', crear('div', {}, perfil.experiencia.map(function (e) {
      return entradaCronologica(e.puesto || e.empresa, e.empresa, periodo(e.inicio, e.fin), e.descripcion);
    }))));
  }

  if ((perfil.habilidades || []).length) {
    contenido.appendChild(seccion('Habilidades', crear('div', { clase: 'etiquetas' }, perfil.habilidades.map(function (h) {
      return crear('span', { clase: 'etiqueta' }, [
        crear('b', { texto: h.nombre }),
        h.nivel ? crear('i', { texto: '  ' + h.nivel }) : null,
      ]);
    }))));
  }

  if ((perfil.proyectos || []).length) {
    contenido.appendChild(seccion('Proyectos', crear('div', { clase: 'rejilla-proyectos' },
      perfil.proyectos.map(bloqueProyecto))));
  }

  if ((perfil.reconocimientos || []).length) {
    contenido.appendChild(seccion('Reconocimientos', crear('div', {}, perfil.reconocimientos.map(function (r) {
      return entradaCronologica(r.titulo, r.otorgadoPor, r.fecha, r.descripcion);
    }))));
  }

  contenido.appendChild(seccion('Currículum', bloqueCv(perfil, slug)));

  var contacto = [];
  if (perfil.contacto && perfil.contacto.email) {
    contacto.push(crear('a', { href: 'mailto:' + perfil.contacto.email }, [
      crear('small', { texto: 'Correo' }), document.createTextNode(perfil.contacto.email),
    ]));
  }
  if (perfil.contacto && perfil.contacto.telefono) {
    contacto.push(crear('a', { href: 'tel:' + perfil.contacto.telefono.replace(/[^+\d]/g, '') }, [
      crear('small', { texto: 'Teléfono' }), document.createTextNode(perfil.contacto.telefono),
    ]));
  }
  if (perfil.contacto && perfil.contacto.sitio) {
    contacto.push(crear('a', { href: urlAbsoluta(perfil.contacto.sitio), target: '_blank', rel: 'noopener noreferrer' }, [
      crear('small', { texto: 'Sitio web' }), document.createTextNode(perfil.contacto.sitio),
    ]));
  }
  if (contacto.length) {
    contenido.appendChild(seccion('Contacto', crear('div', { clase: 'contacto-lista' }, contacto)));
  }

  if ((perfil.enlaces || []).length) {
    contenido.appendChild(seccion('Enlaces profesionales', crear('div', { clase: 'contacto-lista' },
      perfil.enlaces.map(function (e) {
        return crear('a', { href: urlAbsoluta(e.url), target: '_blank', rel: 'noopener noreferrer' }, [
          crear('small', { texto: e.etiqueta || 'Enlace' }),
          document.createTextNode(String(e.url).replace(/^https?:\/\//, '')),
        ]);
      }))));
  }

  if (esBorrador) {
    var aviso = crear('div', { clase: 'aviso aviso--atencion no-imprimir' }, [
      crear('strong', { texto: 'Vista previa del borrador' }),
      document.createTextNode('Así se verá tu perfil cuando lo publiques. Todavía no es lo que ven los visitantes. '),
      crear('a', { href: '/' + slug + '/admin', texto: 'Volver a editar' }),
    ]);
    var cajaAviso = $('#aviso-vista');
    cajaAviso.hidden = false;
    cajaAviso.appendChild(aviso);
  }
}

async function iniciarPerfil() {
  montarBarra();
  var slug = slugDeRuta();
  var parametros = new URLSearchParams(location.search);
  var quiereBorrador = parametros.get('vista') === 'borrador';
  var contenido = $('#contenido');

  if (!slug) { location.href = '/'; return; }

  try {
    if (quiereBorrador) {
      /* El servidor rechaza esta petición si no eres el dueño ni administrador. */
      var privado = await api('/perfil?slug=' + encodeURIComponent(slug));
      dibujarPerfil(privado.borrador, slug, true);
      return;
    }
    var datos = await api('/perfil-publico?slug=' + encodeURIComponent(slug));
    dibujarPerfil(datos.perfil, slug, false);
  } catch (e) {
    contenido.innerHTML = '';
    if (e.estado === 403 || e.estado === 401) {
      contenido.appendChild(crear('div', { clase: 'no-encontrado' }, [
        crear('h1', { texto: 'Sin acceso' }),
        crear('p', { texto: e.message }),
        crear('a', { clase: 'boton boton--primario', href: '/' + slug, texto: 'Ver el perfil público' }),
      ]));
      return;
    }
    contenido.appendChild(crear('div', { clase: 'no-encontrado' }, [
      crear('h1', { texto: 'Perfil no disponible' }),
      crear('p', { texto: e.message }),
      crear('a', { clase: 'boton boton--primario', href: '/', texto: 'Ver todos los perfiles' }),
    ]));
  }
}

iniciarPerfil();
