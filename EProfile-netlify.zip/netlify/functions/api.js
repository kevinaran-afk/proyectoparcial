'use strict';

/* =============================================================================
   EProfile — API del sistema (Netlify Function)
   -----------------------------------------------------------------------------
   POR QUÉ UN SOLO ARCHIVO
   Netlify Drop (deploy manual por ZIP) no ejecuta "npm install" ni un paso de
   build. Para que las funciones arranquen siempre, este archivo no importa
   ninguna dependencia externa ni otros archivos del proyecto: solo usa módulos
   nativos de Node ("crypto") y "fetch" global. Internamente está dividido por
   secciones y la lista completa de endpoints está en TABLA DE RUTAS (sección 7).

   DÓNDE VIVEN LOS DATOS
   Las funciones de Netlify corren en contenedores efímeros de solo lectura: lo
   que se escriba en el disco del deploy se pierde en la siguiente invocación.
   Por eso el JSON del sistema NO se guarda en el deploy, sino como un ARCHIVO
   dentro de Supabase Storage (bucket privado). Sigue siendo un archivo JSON:
   no hay base de datos, ni tablas, ni ORM, ni Supabase Auth.
   ========================================================================== */

const crypto = require('crypto');

/* =============================================================================
   1. CONFIGURACIÓN
   Cada valor se puede definir como variable de entorno en Netlify
   (Site settings > Environment variables) o escribirse aquí directamente.
   Para el proyecto académico basta con escribirlos aquí abajo.
   ========================================================================== */

const CONFIG = {
  // --- Supabase Storage (único servicio externo del proyecto) ---
  SUPABASE_URL:          process.env.SUPABASE_URL          || 'https://gtazbcjiymyiczpxjvmw.supabase.co',
  SUPABASE_SERVICE_KEY:  process.env.SUPABASE_SERVICE_KEY  || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd0YXpiY2ppeW15aWN6cHhqdm13Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4ODkwMTYxOCwiZXhwIjoyMTA0NDc3NjE4fQ.ii_7LwL5fKkdW_wPBFpK1p0KUY83TMlF8c6N3wdihX0',
  SUPABASE_ANON_KEY:     process.env.SUPABASE_ANON_KEY     || '',

  // Bucket PÚBLICO: fotografías de los estudiantes.
  SUPABASE_BUCKET:       process.env.SUPABASE_BUCKET       || 'eprofile-publico',
  // Bucket PRIVADO: archivo data.json del sistema.
  SUPABASE_BUCKET_DATOS: process.env.SUPABASE_BUCKET_DATOS || 'eprofile-datos',
  ARCHIVO_DATOS:         process.env.ARCHIVO_DATOS         || 'data.json',

  // --- Firma de sesiones. Cámbiala por cualquier frase larga. ---
  SECRETO_SESION:        process.env.SECRETO_SESION        || 'f306e55fbc0579cfed82a9413a9de28749ea80824fb5374d',

  HORAS_SESION: 8,
  MAX_IMAGEN_MB: 2,
};

/* Cuentas con las que arranca el sistema la primera vez. Después de la primera
   ejecución las contraseñas viven hasheadas dentro de data.json y cambiarlas
   aquí ya no tiene efecto (se cambian desde el panel de administrador). */
const CUENTAS_INICIALES = {
  admin:    { email: 'admin@eprofile.edu',            password: 'Admin2026*',     nombre: 'Administración' },
  fernanda: { email: 'fernanda.delangel@iest.edu.mx', password: 'Fernanda2026*',  nombre: 'Fernanda' },
  kevin:    { email: 'kevin.aran@iest.edu.mx',        password: 'Companero2026*', nombre: 'Kevin Leonardo Aran Cruz' },
};

const SLUGS_RESERVADOS = [
  'admin', 'api', 'entrar', 'salir', 'assets', 'data', 'netlify', 'tarjeta',
  'index', 'perfil', 'panel', '404', 'favicon', 'static', 'public',
];

/* =============================================================================
   2. SEGURIDAD: hash de contraseñas y firma de sesiones
   ========================================================================== */

const ITERACIONES = 150000;

function hashPassword(password) {
  const sal = crypto.randomBytes(16).toString('hex');
  const derivada = crypto.pbkdf2Sync(String(password), sal, ITERACIONES, 32, 'sha256').toString('hex');
  return 'pbkdf2$' + ITERACIONES + '$' + sal + '$' + derivada;
}

function verificarPassword(password, guardado) {
  try {
    const partes = String(guardado || '').split('$');
    if (partes[0] !== 'pbkdf2') return false;
    const calculada = crypto.pbkdf2Sync(String(password), partes[2], parseInt(partes[1], 10), 32, 'sha256');
    const esperada = Buffer.from(partes[3], 'hex');
    if (calculada.length !== esperada.length) return false;
    return crypto.timingSafeEqual(calculada, esperada);
  } catch (e) {
    return false;
  }
}

function b64url(valor) {
  return Buffer.from(valor).toString('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function deB64url(valor) {
  return Buffer.from(String(valor).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

function firmaDe(cuerpo) {
  return b64url(crypto.createHmac('sha256', CONFIG.SECRETO_SESION).update(cuerpo).digest());
}

function crearToken(usuario) {
  const carga = {
    sub: usuario.id,
    rol: usuario.rol,
    estudianteId: usuario.estudianteId || null,
    email: usuario.email,
    exp: Date.now() + CONFIG.HORAS_SESION * 3600 * 1000,
  };
  const cuerpo = b64url(JSON.stringify(carga));
  return cuerpo + '.' + firmaDe(cuerpo);
}

function leerToken(token) {
  try {
    if (!token || token.indexOf('.') < 0) return null;
    const corte = token.lastIndexOf('.');
    const cuerpo = token.slice(0, corte);
    const firma = Buffer.from(token.slice(corte + 1));
    const esperada = Buffer.from(firmaDe(cuerpo));
    if (firma.length !== esperada.length) return null;
    if (!crypto.timingSafeEqual(firma, esperada)) return null;
    const carga = JSON.parse(deB64url(cuerpo).toString('utf8'));
    if (!carga.exp || carga.exp < Date.now()) return null;
    return carga;
  } catch (e) {
    return null;
  }
}

function cookieSesion(token) {
  return 'ep_sesion=' + token + '; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=' +
    (CONFIG.HORAS_SESION * 3600);
}

function cookieCerrada() {
  return 'ep_sesion=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0';
}

function tokenDePeticion(event) {
  const cabeceras = event.headers || {};
  const cookie = cabeceras.cookie || cabeceras.Cookie || '';
  const encontrado = cookie.split(';')
    .map(function (p) { return p.trim(); })
    .find(function (p) { return p.indexOf('ep_sesion=') === 0; });
  if (encontrado) return encontrado.slice('ep_sesion='.length);
  const auth = cabeceras.authorization || cabeceras.Authorization || '';
  if (auth.indexOf('Bearer ') === 0) return auth.slice(7);
  return '';
}

/* =============================================================================
   3. SEMILLA INICIAL DEL JSON
   ========================================================================== */

function perfilVacio() {
  return {
    nombre: '', profesion: '', resena: '', fotoUrl: '', ubicacion: '',
    contacto: { email: '', telefono: '', sitio: '' },
    enlaces: [], formacion: [], experiencia: [], habilidades: [],
    proyectos: [], reconocimientos: [],
    plantillaCv: 'minimalista',
  };
}

function semilla() {
  const ahora = new Date().toISOString();

  const fernandaPublicado = Object.assign(perfilVacio(), {
    nombre: 'Fernanda',
    profesion: 'Estudiante de Ingeniería en Sistemas y Negocios Digitales',
    resena: 'Estudiante de Ingeniería en Sistemas y Negocios Digitales. Me interesa el desarrollo web y la forma en que la tecnología ordena los procesos de un negocio.',
    contacto: { email: CUENTAS_INICIALES.fernanda.email, telefono: '', sitio: '' },
    plantillaCv: 'minimalista',
  });

  /* El borrador arranca con contenido adicional que todavía NO está publicado.
     Sirve para demostrar en la presentación la diferencia borrador / publicado. */
  const fernandaBorrador = Object.assign(JSON.parse(JSON.stringify(fernandaPublicado)), {
    resena: 'Estudiante de Ingeniería en Sistemas y Negocios Digitales. Me interesa el desarrollo web y la forma en que la tecnología ordena los procesos de un negocio. Actualmente trabajo en proyectos de clase con JavaScript.',
    habilidades: [
      { id: 'h1', nombre: 'JavaScript', nivel: 'Intermedio' },
      { id: 'h2', nombre: 'HTML y CSS', nivel: 'Intermedio' },
      { id: 'h3', nombre: 'Análisis de procesos', nivel: 'Básico' },
    ],
    proyectos: [{
      id: 'p1',
      nombre: 'EProfile',
      descripcion: 'Plataforma de perfiles profesionales para estudiantes, con panel de edición, borradores, publicación, CV en PDF, código QR y tarjeta digital.',
      tecnologias: 'JavaScript, Netlify Functions, Supabase Storage',
      rol: 'Desarrollo del panel de edición y del perfil público',
      enlace: '', repositorio: '', academico: true,
    }],
  });

  const kevinPublicado = Object.assign(perfilVacio(), {
    nombre: CUENTAS_INICIALES.kevin.nombre,
    profesion: 'Estudiante de Ingeniería en Sistemas y Negocios Digitales',
    contacto: { email: CUENTAS_INICIALES.kevin.email, telefono: '', sitio: '' },
    plantillaCv: 'profesional',
  });

  return {
    version: 1,
    creadoEn: ahora,
    actualizadoEn: ahora,
    usuarios: [
      {
        id: 'u-admin', email: CUENTAS_INICIALES.admin.email, nombre: CUENTAS_INICIALES.admin.nombre,
        rol: 'admin', estudianteId: null, activo: true,
        hash: hashPassword(CUENTAS_INICIALES.admin.password), creadoEn: ahora,
      },
      {
        id: 'u-fernanda', email: CUENTAS_INICIALES.fernanda.email, nombre: CUENTAS_INICIALES.fernanda.nombre,
        rol: 'estudiante', estudianteId: 'e-fernanda', activo: true,
        hash: hashPassword(CUENTAS_INICIALES.fernanda.password), creadoEn: ahora,
      },
      {
        id: 'u-kevin', email: CUENTAS_INICIALES.kevin.email, nombre: CUENTAS_INICIALES.kevin.nombre,
        rol: 'estudiante', estudianteId: 'e-kevin', activo: true,
        hash: hashPassword(CUENTAS_INICIALES.kevin.password), creadoEn: ahora,
      },
    ],
    estudiantes: [
      {
        id: 'e-fernanda', slug: 'fernanda', activo: true,
        creadoEn: ahora, actualizadoEn: ahora, publicadoEn: ahora,
        borrador: fernandaBorrador, publicado: fernandaPublicado,
      },
      {
        id: 'e-kevin', slug: 'kevin', activo: true,
        creadoEn: ahora, actualizadoEn: ahora, publicadoEn: ahora,
        borrador: JSON.parse(JSON.stringify(kevinPublicado)), publicado: kevinPublicado,
      },
    ],
  };
}

/* =============================================================================
   4. ALMACENAMIENTO — el archivo JSON dentro de Supabase Storage
   ========================================================================== */

function claveStorage() {
  return CONFIG.SUPABASE_SERVICE_KEY || CONFIG.SUPABASE_ANON_KEY;
}

function supabaseListo() {
  return Boolean(CONFIG.SUPABASE_URL && claveStorage());
}

function cabecerasSupabase(extra) {
  const clave = claveStorage();
  return Object.assign({ apikey: clave, authorization: 'Bearer ' + clave }, extra || {});
}

function urlObjeto(bucket, ruta) {
  return CONFIG.SUPABASE_URL.replace(/\/+$/, '') + '/storage/v1/object/' + bucket + '/' + ruta;
}

async function descargarJson() {
  const respuesta = await fetch(urlObjeto(CONFIG.SUPABASE_BUCKET_DATOS, CONFIG.ARCHIVO_DATOS), {
    headers: cabecerasSupabase({ 'cache-control': 'no-cache' }),
  });
  if (respuesta.status === 404 || respuesta.status === 400) return null; // aún no existe
  if (!respuesta.ok) throw new Error('storage-lectura-' + respuesta.status);
  return JSON.parse(await respuesta.text());
}

async function subirJson(datos) {
  const respuesta = await fetch(urlObjeto(CONFIG.SUPABASE_BUCKET_DATOS, CONFIG.ARCHIVO_DATOS), {
    method: 'POST',
    headers: cabecerasSupabase({
      'content-type': 'application/json',
      'cache-control': 'no-cache',
      'x-upsert': 'true',
    }),
    body: JSON.stringify(datos, null, 2),
  });
  if (!respuesta.ok) {
    const detalle = (await respuesta.text()).slice(0, 300);
    throw new Error('storage-escritura-' + respuesta.status + ' ' + detalle);
  }
}

async function subirImagen(ruta, contenido, tipo) {
  const respuesta = await fetch(urlObjeto(CONFIG.SUPABASE_BUCKET, ruta), {
    method: 'POST',
    headers: cabecerasSupabase({
      'content-type': tipo,
      'cache-control': '31536000',
      'x-upsert': 'true',
    }),
    body: contenido,
  });
  if (!respuesta.ok) {
    const detalle = (await respuesta.text()).slice(0, 300);
    throw new Error('storage-imagen-' + respuesta.status + ' ' + detalle);
  }
  return CONFIG.SUPABASE_URL.replace(/\/+$/, '') +
    '/storage/v1/object/public/' + CONFIG.SUPABASE_BUCKET + '/' + ruta;
}

/* Respaldo temporal en memoria: permite probar la plataforma completa apenas se
   sube el ZIP, antes de configurar Supabase. NO es persistente y la interfaz lo
   avisa con un mensaje visible en los paneles. */
let datosEnMemoria = null;

async function cargarDatos() {
  if (supabaseListo()) {
    const guardado = await descargarJson();
    if (guardado) return guardado;
    const nuevo = semilla();
    await subirJson(nuevo);
    return nuevo;
  }
  if (!datosEnMemoria) datosEnMemoria = semilla();
  return datosEnMemoria;
}

async function guardarDatos(datos) {
  datos.actualizadoEn = new Date().toISOString();
  if (supabaseListo()) {
    await subirJson(datos);
  } else {
    datosEnMemoria = datos;
  }
}

function modoPersistencia() {
  return supabaseListo() ? 'supabase' : 'temporal';
}

/* =============================================================================
   5. UTILIDADES DE RESPUESTA Y VALIDACIÓN
   ========================================================================== */

function responder(estado, cuerpo, cookies) {
  const salida = {
    statusCode: estado,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(cuerpo),
  };
  if (cookies) salida.multiValueHeaders = { 'Set-Cookie': cookies };
  return salida;
}

function correcto(cuerpo, cookies) {
  return responder(200, Object.assign({ ok: true, persistencia: modoPersistencia() }, cuerpo || {}), cookies);
}

function fallo(estado, mensaje, extra) {
  return responder(estado, Object.assign({ ok: false, mensaje: mensaje }, extra || {}));
}

function texto(valor, maximo) {
  return String(valor === null || valor === undefined ? '' : valor).trim().slice(0, maximo || 400);
}

function emailValido(valor) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(valor || '').trim());
}

function normalizarSlug(valor) {
  return String(valor || '').toLowerCase().trim()
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

function slugValido(valor) {
  return /^[a-z0-9][a-z0-9-]{1,38}[a-z0-9]$/.test(valor) && SLUGS_RESERVADOS.indexOf(valor) < 0;
}

function idNuevo(prefijo) {
  return prefijo + '-' + Date.now().toString(36) + crypto.randomBytes(3).toString('hex');
}

function leerCuerpo(event) {
  if (!event.body) return {};
  const crudo = event.isBase64Encoded ? Buffer.from(event.body, 'base64').toString('utf8') : event.body;
  try { return JSON.parse(crudo); } catch (e) { return {}; }
}

/* Limpia y da forma al perfil recibido del navegador. Nunca se guarda lo que
   llega tal cual: solo los campos conocidos y con longitud acotada. */
function normalizarPerfil(entrada, anterior) {
  const previo = anterior || perfilVacio();
  const p = entrada && typeof entrada === 'object' ? entrada : {};
  const contacto = p.contacto && typeof p.contacto === 'object' ? p.contacto : {};

  function lista(origen, maximo, mapear) {
    if (!Array.isArray(origen)) return [];
    return origen.slice(0, maximo).map(function (elemento, indice) {
      const base = elemento && typeof elemento === 'object' ? elemento : {};
      const resultado = mapear(base);
      resultado.id = texto(base.id, 40) || ('i' + indice + Date.now().toString(36));
      return resultado;
    });
  }

  const plantillas = ['minimalista', 'profesional', 'clasica'];
  const plantilla = plantillas.indexOf(texto(p.plantillaCv, 20)) >= 0
    ? texto(p.plantillaCv, 20) : previo.plantillaCv || 'minimalista';

  return {
    nombre: texto(p.nombre, 90),
    profesion: texto(p.profesion, 120),
    resena: texto(p.resena, 900),
    /* La foto no se edita por formulario: solo la cambia el endpoint de subida. */
    fotoUrl: texto(previo.fotoUrl, 500),
    ubicacion: texto(p.ubicacion, 90),
    contacto: {
      email: texto(contacto.email, 120),
      telefono: texto(contacto.telefono, 40),
      sitio: texto(contacto.sitio, 200),
    },
    enlaces: lista(p.enlaces, 12, function (e) {
      return { etiqueta: texto(e.etiqueta, 40), url: texto(e.url, 300) };
    }),
    formacion: lista(p.formacion, 20, function (e) {
      return {
        institucion: texto(e.institucion, 120), titulo: texto(e.titulo, 120),
        inicio: texto(e.inicio, 20), fin: texto(e.fin, 20), descripcion: texto(e.descripcion, 600),
      };
    }),
    experiencia: lista(p.experiencia, 20, function (e) {
      return {
        empresa: texto(e.empresa, 120), puesto: texto(e.puesto, 120),
        inicio: texto(e.inicio, 20), fin: texto(e.fin, 20), descripcion: texto(e.descripcion, 600),
      };
    }),
    habilidades: lista(p.habilidades, 40, function (e) {
      return { nombre: texto(e.nombre, 60), nivel: texto(e.nivel, 30) };
    }),
    proyectos: lista(p.proyectos, 30, function (e) {
      return {
        nombre: texto(e.nombre, 120), descripcion: texto(e.descripcion, 800),
        tecnologias: texto(e.tecnologias, 200), rol: texto(e.rol, 120),
        enlace: texto(e.enlace, 300), repositorio: texto(e.repositorio, 300),
        academico: Boolean(e.academico),
      };
    }),
    reconocimientos: lista(p.reconocimientos, 20, function (e) {
      return {
        titulo: texto(e.titulo, 120), otorgadoPor: texto(e.otorgadoPor, 120),
        fecha: texto(e.fecha, 20), descripcion: texto(e.descripcion, 600),
      };
    }),
    plantillaCv: plantilla,
  };
}

function faltantesParaPublicar(perfil) {
  const faltan = [];
  if (!perfil.nombre) faltan.push('nombre completo');
  if (!perfil.profesion) faltan.push('carrera o profesión');
  return faltan;
}

/* =============================================================================
   6. AUTORIZACIÓN
   Toda decisión de permisos ocurre aquí, en el servidor. El navegador solo
   oculta botones; el aislamiento real entre estudiantes se aplica en esta capa.
   ========================================================================== */

function sesionDe(event, datos) {
  const carga = leerToken(tokenDePeticion(event));
  if (!carga) return null;
  const usuario = datos.usuarios.find(function (u) { return u.id === carga.sub; });
  if (!usuario || !usuario.activo) return null;
  /* El rol se vuelve a leer del JSON, no del token: si el administrador cambia
     el rol o desactiva la cuenta, la sesión abierta deja de tener permisos. */
  return usuario;
}

function estudiantePorSlug(datos, slug) {
  return datos.estudiantes.find(function (e) { return e.slug === slug; }) || null;
}

function puedeEditar(usuario, estudiante) {
  if (!usuario || !estudiante) return false;
  if (usuario.rol === 'admin') return true;
  return usuario.rol === 'estudiante' && usuario.estudianteId === estudiante.id;
}

function publico(usuario) {
  return {
    id: usuario.id, email: usuario.email, nombre: usuario.nombre,
    rol: usuario.rol, estudianteId: usuario.estudianteId,
  };
}

function resumenEstudiante(datos, estudiante) {
  const cuenta = datos.usuarios.find(function (u) { return u.estudianteId === estudiante.id; });
  const publicado = estudiante.publicado;
  return {
    id: estudiante.id,
    slug: estudiante.slug,
    activo: estudiante.activo,
    nombre: (estudiante.borrador && estudiante.borrador.nombre) || (publicado && publicado.nombre) || '',
    profesion: (publicado && publicado.profesion) || (estudiante.borrador && estudiante.borrador.profesion) || '',
    email: cuenta ? cuenta.email : '',
    cuentaActiva: cuenta ? cuenta.activo : false,
    publicado: Boolean(publicado),
    cambiosSinPublicar: JSON.stringify(estudiante.borrador) !== JSON.stringify(estudiante.publicado),
    actualizadoEn: estudiante.actualizadoEn,
    publicadoEn: estudiante.publicadoEn,
    fotoUrl: (publicado && publicado.fotoUrl) || (estudiante.borrador && estudiante.borrador.fotoUrl) || '',
  };
}

/* =============================================================================
   7. TABLA DE RUTAS

   Públicas
     GET    /api/estado                 estado del sistema y persistencia
     GET    /api/perfiles               directorio de perfiles publicados
     GET    /api/perfil-publico?slug=   perfil publicado de un estudiante
     POST   /api/login                  inicio de sesión
     POST   /api/logout                 cierre de sesión
     GET    /api/sesion                 usuario de la sesión actual

   Estudiante (solo su propio perfil) y administrador (cualquiera)
     GET    /api/perfil?slug=           borrador + publicado + metadatos
     PUT    /api/perfil?slug=           guardar borrador
     POST   /api/publicar?slug=         publicar el borrador
     POST   /api/despublicar?slug=      retirar de la vista pública
     POST   /api/foto?slug=             subir fotografía a Supabase Storage
     POST   /api/password               cambiar la propia contraseña

   Solo administrador
     GET    /api/admin/estudiantes      listado completo
     POST   /api/admin/estudiantes      crear estudiante + cuenta
     PUT    /api/admin/estudiantes?id=  editar datos y estado
     DELETE /api/admin/estudiantes?id=  eliminar estudiante y su cuenta
     POST   /api/admin/password?id=     restablecer contraseña
     GET    /api/admin/exportar         descargar el data.json completo
   ========================================================================== */

exports.handler = async function (event) {
  let ruta = String(event.path || '')
    .replace(/^\/\.netlify\/functions\/api/, '')
    .replace(/^\/api/, '');
  if (!ruta.startsWith('/')) ruta = '/' + ruta;
  ruta = ruta.replace(/\/+$/, '') || '/';

  const metodo = (event.httpMethod || 'GET').toUpperCase();
  const consulta = event.queryStringParameters || {};

  try {
    if (ruta === '/estado' && metodo === 'GET') {
      return correcto({ supabase: supabaseListo(), bucket: CONFIG.SUPABASE_BUCKET });
    }

    const datos = await cargarDatos();

    /* ---------------------------------------------------------------- sesión */

    if (ruta === '/login' && metodo === 'POST') {
      const cuerpo = leerCuerpo(event);
      const email = texto(cuerpo.email, 120).toLowerCase();
      const password = String(cuerpo.password || '');

      if (!email || !password) return fallo(400, 'Escribe tu correo y tu contraseña.');
      if (!emailValido(email)) return fallo(400, 'El correo no tiene un formato válido.');

      const usuario = datos.usuarios.find(function (u) { return u.email.toLowerCase() === email; });
      /* Mismo mensaje para usuario inexistente y contraseña incorrecta. */
      if (!usuario || !verificarPassword(password, usuario.hash)) {
        return fallo(401, 'Correo o contraseña incorrectos.');
      }
      if (!usuario.activo) return fallo(403, 'Esta cuenta está desactivada. Contacta al administrador.');

      let slug = null;
      if (usuario.estudianteId) {
        const estudiante = datos.estudiantes.find(function (e) { return e.id === usuario.estudianteId; });
        slug = estudiante ? estudiante.slug : null;
      }
      return correcto({ usuario: publico(usuario), slug: slug }, [cookieSesion(crearToken(usuario))]);
    }

    if (ruta === '/logout' && metodo === 'POST') {
      return correcto({}, [cookieCerrada()]);
    }

    if (ruta === '/sesion' && metodo === 'GET') {
      const usuario = sesionDe(event, datos);
      if (!usuario) return correcto({ usuario: null });
      let slug = null;
      if (usuario.estudianteId) {
        const estudiante = datos.estudiantes.find(function (e) { return e.id === usuario.estudianteId; });
        slug = estudiante ? estudiante.slug : null;
      }
      return correcto({ usuario: publico(usuario), slug: slug });
    }

    /* --------------------------------------------------------------- público */

    if (ruta === '/perfiles' && metodo === 'GET') {
      const lista = datos.estudiantes
        .filter(function (e) { return e.activo && e.publicado && e.publicado.nombre; })
        .map(function (e) {
          return {
            slug: e.slug,
            nombre: e.publicado.nombre,
            profesion: e.publicado.profesion,
            fotoUrl: e.publicado.fotoUrl,
            actualizadoEn: e.publicadoEn,
          };
        });
      return correcto({ perfiles: lista });
    }

    if (ruta === '/perfil-publico' && metodo === 'GET') {
      const slug = normalizarSlug(consulta.slug);
      const estudiante = estudiantePorSlug(datos, slug);
      if (!estudiante || !estudiante.activo || !estudiante.publicado) {
        return fallo(404, 'Este perfil no existe o todavía no ha sido publicado.');
      }
      return correcto({ slug: estudiante.slug, perfil: estudiante.publicado, publicadoEn: estudiante.publicadoEn });
    }

    /* ------------------------------------------------- perfil autenticado */

    if (ruta === '/perfil') {
      const usuario = sesionDe(event, datos);
      if (!usuario) return fallo(401, 'Tu sesión terminó. Vuelve a iniciar sesión.');

      const estudiante = estudiantePorSlug(datos, normalizarSlug(consulta.slug));
      if (!estudiante) return fallo(404, 'No encontramos este perfil.');
      if (!puedeEditar(usuario, estudiante)) {
        return fallo(403, 'No tienes permisos para acceder a este perfil.');
      }

      if (metodo === 'GET') {
        return correcto({
          slug: estudiante.slug,
          activo: estudiante.activo,
          borrador: estudiante.borrador,
          publicado: estudiante.publicado,
          actualizadoEn: estudiante.actualizadoEn,
          publicadoEn: estudiante.publicadoEn,
          cambiosSinPublicar: JSON.stringify(estudiante.borrador) !== JSON.stringify(estudiante.publicado),
        });
      }

      if (metodo === 'PUT') {
        const cuerpo = leerCuerpo(event);
        estudiante.borrador = normalizarPerfil(cuerpo.perfil, estudiante.borrador);
        estudiante.actualizadoEn = new Date().toISOString();
        await guardarDatos(datos);
        return correcto({
          borrador: estudiante.borrador,
          actualizadoEn: estudiante.actualizadoEn,
          cambiosSinPublicar: JSON.stringify(estudiante.borrador) !== JSON.stringify(estudiante.publicado),
        });
      }

      return fallo(405, 'Operación no permitida.');
    }

    if (ruta === '/publicar' && metodo === 'POST') {
      const usuario = sesionDe(event, datos);
      if (!usuario) return fallo(401, 'Tu sesión terminó. Vuelve a iniciar sesión.');
      const estudiante = estudiantePorSlug(datos, normalizarSlug(consulta.slug));
      if (!estudiante) return fallo(404, 'No encontramos este perfil.');
      if (!puedeEditar(usuario, estudiante)) return fallo(403, 'No tienes permisos para publicar este perfil.');

      const faltan = faltantesParaPublicar(estudiante.borrador);
      if (faltan.length) {
        return fallo(400, 'Completa tu ' + faltan.join(' y tu ') + ' antes de publicar.', { faltantes: faltan });
      }

      estudiante.publicado = JSON.parse(JSON.stringify(estudiante.borrador));
      estudiante.publicadoEn = new Date().toISOString();
      estudiante.actualizadoEn = estudiante.publicadoEn;
      await guardarDatos(datos);
      return correcto({ publicado: estudiante.publicado, publicadoEn: estudiante.publicadoEn, cambiosSinPublicar: false });
    }

    if (ruta === '/despublicar' && metodo === 'POST') {
      const usuario = sesionDe(event, datos);
      if (!usuario) return fallo(401, 'Tu sesión terminó. Vuelve a iniciar sesión.');
      const estudiante = estudiantePorSlug(datos, normalizarSlug(consulta.slug));
      if (!estudiante) return fallo(404, 'No encontramos este perfil.');
      if (!puedeEditar(usuario, estudiante)) return fallo(403, 'No tienes permisos sobre este perfil.');

      estudiante.publicado = null;
      estudiante.publicadoEn = null;
      estudiante.actualizadoEn = new Date().toISOString();
      await guardarDatos(datos);
      return correcto({ publicado: null, cambiosSinPublicar: true });
    }

    /* --------------------------------------------------------- fotografía */

    if (ruta === '/foto' && metodo === 'POST') {
      const usuario = sesionDe(event, datos);
      if (!usuario) return fallo(401, 'Tu sesión terminó. Vuelve a iniciar sesión.');
      const estudiante = estudiantePorSlug(datos, normalizarSlug(consulta.slug));
      if (!estudiante) return fallo(404, 'No encontramos este perfil.');
      if (!puedeEditar(usuario, estudiante)) return fallo(403, 'No tienes permisos para cambiar esta fotografía.');

      const cuerpo = leerCuerpo(event);

      /* Quitar la fotografía solo borra la URL del JSON. El archivo anterior se
         queda en Supabase Storage: así no se rompe un perfil ya publicado que
         todavía apunta a esa imagen. */
      if (cuerpo.quitar) {
        estudiante.borrador.fotoUrl = '';
        estudiante.actualizadoEn = new Date().toISOString();
        await guardarDatos(datos);
        return correcto({ fotoUrl: '', cambiosSinPublicar: true });
      }

      /* Se valida el archivo antes de mirar la configuración, para que el
         mensaje hable del problema real del usuario y no del servidor. */
      const permitidos = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
      const tipo = texto(cuerpo.tipo, 40);
      if (!permitidos[tipo]) return fallo(400, 'Solo se aceptan imágenes JPG, PNG o WEBP.');

      const base64 = String(cuerpo.datos || '').split(',').pop();
      if (!base64) return fallo(400, 'No recibimos la imagen. Vuelve a intentarlo.');
      const binario = Buffer.from(base64, 'base64');
      if (!binario.length) return fallo(400, 'No recibimos la imagen. Vuelve a intentarlo.');
      if (binario.length > CONFIG.MAX_IMAGEN_MB * 1024 * 1024) {
        return fallo(413, 'La imagen supera ' + CONFIG.MAX_IMAGEN_MB + ' MB. Usa una más ligera.');
      }

      if (!supabaseListo()) {
        return fallo(503, 'El almacenamiento de imágenes todavía no está configurado. Revisa las claves de Supabase en el archivo de la función.');
      }

      const ruta_archivo = 'fotos/' + estudiante.slug + '-' + Date.now() + '.' + permitidos[tipo];
      const url = await subirImagen(ruta_archivo, binario, tipo);

      /* En el JSON solo se guarda la URL. La imagen vive en Supabase Storage. */
      estudiante.borrador.fotoUrl = url;
      estudiante.actualizadoEn = new Date().toISOString();
      await guardarDatos(datos);
      return correcto({ fotoUrl: url, cambiosSinPublicar: true });
    }

    /* ------------------------------------------------ contraseña propia */

    if (ruta === '/password' && metodo === 'POST') {
      const usuario = sesionDe(event, datos);
      if (!usuario) return fallo(401, 'Tu sesión terminó. Vuelve a iniciar sesión.');
      const cuerpo = leerCuerpo(event);
      const actual = String(cuerpo.actual || '');
      const nueva = String(cuerpo.nueva || '');
      if (!verificarPassword(actual, usuario.hash)) return fallo(401, 'La contraseña actual no es correcta.');
      if (nueva.length < 8) return fallo(400, 'La nueva contraseña debe tener al menos 8 caracteres.');
      usuario.hash = hashPassword(nueva);
      await guardarDatos(datos);
      return correcto({});
    }

    /* ------------------------------------------------------ administrador */

    if (ruta.indexOf('/admin') === 0) {
      const usuario = sesionDe(event, datos);
      if (!usuario) return fallo(401, 'Tu sesión terminó. Vuelve a iniciar sesión.');
      if (usuario.rol !== 'admin') return fallo(403, 'No tienes permisos para acceder a esta sección.');

      if (ruta === '/admin/estudiantes' && metodo === 'GET') {
        return correcto({
          estudiantes: datos.estudiantes.map(function (e) { return resumenEstudiante(datos, e); }),
        });
      }

      if (ruta === '/admin/estudiantes' && metodo === 'POST') {
        const cuerpo = leerCuerpo(event);
        const nombre = texto(cuerpo.nombre, 90);
        const email = texto(cuerpo.email, 120).toLowerCase();
        const slug = normalizarSlug(cuerpo.slug || nombre);
        const password = String(cuerpo.password || '');

        if (!nombre) return fallo(400, 'Escribe el nombre del estudiante.');
        if (!emailValido(email)) return fallo(400, 'El correo no tiene un formato válido.');
        if (datos.usuarios.some(function (u) { return u.email.toLowerCase() === email; })) {
          return fallo(409, 'Ya existe una cuenta con ese correo.');
        }
        if (!slugValido(slug)) return fallo(400, 'La dirección del perfil solo admite letras, números y guiones, y no puede ser una palabra reservada.');
        if (estudiantePorSlug(datos, slug)) return fallo(409, 'Ya existe un perfil con esa dirección.');
        if (password.length < 8) return fallo(400, 'La contraseña debe tener al menos 8 caracteres.');

        const ahora = new Date().toISOString();
        const perfil = Object.assign(perfilVacio(), { nombre: nombre, contacto: { email: email, telefono: '', sitio: '' } });
        const estudiante = {
          id: idNuevo('e'), slug: slug, activo: true,
          creadoEn: ahora, actualizadoEn: ahora, publicadoEn: null,
          borrador: perfil, publicado: null,
        };
        datos.estudiantes.push(estudiante);
        datos.usuarios.push({
          id: idNuevo('u'), email: email, nombre: nombre, rol: 'estudiante',
          estudianteId: estudiante.id, activo: true, hash: hashPassword(password), creadoEn: ahora,
        });
        await guardarDatos(datos);
        return correcto({ estudiante: resumenEstudiante(datos, estudiante) });
      }

      if (ruta === '/admin/estudiantes' && metodo === 'PUT') {
        const cuerpo = leerCuerpo(event);
        const estudiante = datos.estudiantes.find(function (e) { return e.id === texto(consulta.id, 40); });
        if (!estudiante) return fallo(404, 'No encontramos este estudiante.');
        const cuenta = datos.usuarios.find(function (u) { return u.estudianteId === estudiante.id; });

        if (cuerpo.slug !== undefined) {
          const slug = normalizarSlug(cuerpo.slug);
          if (!slugValido(slug)) return fallo(400, 'La dirección del perfil solo admite letras, números y guiones, y no puede ser una palabra reservada.');
          const otro = estudiantePorSlug(datos, slug);
          if (otro && otro.id !== estudiante.id) return fallo(409, 'Ya existe un perfil con esa dirección.');
          estudiante.slug = slug;
        }
        if (cuerpo.email !== undefined && cuenta) {
          const email = texto(cuerpo.email, 120).toLowerCase();
          if (!emailValido(email)) return fallo(400, 'El correo no tiene un formato válido.');
          const ocupado = datos.usuarios.some(function (u) { return u.email.toLowerCase() === email && u.id !== cuenta.id; });
          if (ocupado) return fallo(409, 'Ya existe una cuenta con ese correo.');
          cuenta.email = email;
        }
        if (cuerpo.nombre !== undefined) {
          const nombre = texto(cuerpo.nombre, 90);
          if (!nombre) return fallo(400, 'El nombre no puede quedar vacío.');
          if (cuenta) cuenta.nombre = nombre;
          estudiante.borrador.nombre = nombre;
        }
        if (cuerpo.activo !== undefined) {
          estudiante.activo = Boolean(cuerpo.activo);
          if (cuenta) cuenta.activo = Boolean(cuerpo.activo);
        }
        estudiante.actualizadoEn = new Date().toISOString();
        await guardarDatos(datos);
        return correcto({ estudiante: resumenEstudiante(datos, estudiante) });
      }

      if (ruta === '/admin/estudiantes' && metodo === 'DELETE') {
        const id = texto(consulta.id, 40);
        const indice = datos.estudiantes.findIndex(function (e) { return e.id === id; });
        if (indice < 0) return fallo(404, 'No encontramos este estudiante.');
        datos.estudiantes.splice(indice, 1);
        datos.usuarios = datos.usuarios.filter(function (u) { return u.estudianteId !== id; });
        await guardarDatos(datos);
        return correcto({ eliminado: id });
      }

      if (ruta === '/admin/password' && metodo === 'POST') {
        const cuerpo = leerCuerpo(event);
        const nueva = String(cuerpo.password || '');
        if (nueva.length < 8) return fallo(400, 'La contraseña debe tener al menos 8 caracteres.');
        const cuenta = datos.usuarios.find(function (u) { return u.estudianteId === texto(consulta.id, 40); });
        if (!cuenta) return fallo(404, 'Este estudiante no tiene una cuenta asociada.');
        cuenta.hash = hashPassword(nueva);
        await guardarDatos(datos);
        return correcto({ email: cuenta.email });
      }

      if (ruta === '/admin/exportar' && metodo === 'GET') {
        /* Copia del JSON sin los hashes, para revisarlo o respaldarlo. */
        const copia = JSON.parse(JSON.stringify(datos));
        copia.usuarios = copia.usuarios.map(function (u) {
          u.hash = '(oculto)';
          return u;
        });
        return responder(200, copia);
      }

      return fallo(404, 'Operación no disponible.');
    }

    return fallo(404, 'Operación no disponible.');
  } catch (error) {
    /* Nunca se devuelve el detalle técnico al navegador; queda en los logs. */
    console.error('[EProfile]', error && error.message, error && error.stack);
    return fallo(500, 'Los datos no pudieron procesarse. Intenta nuevamente en un momento.');
  }
};
